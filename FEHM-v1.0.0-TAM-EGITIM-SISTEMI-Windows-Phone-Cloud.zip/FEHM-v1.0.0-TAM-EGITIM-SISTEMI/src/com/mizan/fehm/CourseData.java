package com.mizan.fehm;

import android.content.Context;
import org.json.*;
import java.io.*;
import java.util.*;

final class CourseData {
    static final class Letter {String arabic,name,sound,note,example;}
    static final class Word {String id,arabic,latin,meaning,root,family,type;}
    static final class Grammar {String id,title,meaning,body,example;}
    final ArrayList<Letter> letters=new ArrayList<Letter>();
    final ArrayList<Letter> marks=new ArrayList<Letter>();
    final ArrayList<Word> words=new ArrayList<Word>();
    final ArrayList<Grammar> grammar=new ArrayList<Grammar>();
    private static CourseData INSTANCE;
    static synchronized CourseData get(Context c){if(INSTANCE==null)INSTANCE=load(c);return INSTANCE;}
    private static CourseData load(Context c){CourseData d=new CourseData();try{InputStream in=c.getAssets().open("fehm_seed.json");BufferedReader r=new BufferedReader(new InputStreamReader(in,"UTF-8"));StringBuilder b=new StringBuilder();String line;while((line=r.readLine())!=null)b.append(line);r.close();JSONObject o=new JSONObject(b.toString());readLetters(o.optJSONArray("letters"),d.letters);readLetters(o.optJSONArray("marks"),d.marks);JSONArray w=o.optJSONArray("words");if(w!=null)for(int i=0;i<w.length();i++){JSONObject x=w.getJSONObject(i);Word z=new Word();z.id=x.optString("id");z.arabic=x.optString("arabic");z.latin=x.optString("latin");z.meaning=x.optString("meaning");z.root=x.optString("root");z.family=x.optString("family");z.type=x.optString("type");d.words.add(z);}JSONArray g=o.optJSONArray("grammar");if(g!=null)for(int i=0;i<g.length();i++){JSONObject x=g.getJSONObject(i);Grammar z=new Grammar();z.id=x.optString("id");z.title=x.optString("title");z.meaning=x.optString("meaning");z.body=x.optString("body");z.example=x.optString("example");d.grammar.add(z);}}catch(Exception ignored){}return d;}
    private static void readLetters(JSONArray a,ArrayList<Letter> out)throws Exception{if(a==null)return;for(int i=0;i<a.length();i++){JSONObject x=a.getJSONObject(i);Letter z=new Letter();z.arabic=x.optString("arabic");z.name=x.optString("name");z.sound=x.optString("sound");z.note=x.optString("note");z.example=x.optString("example");out.add(z);}}
    private CourseData(){}
}
