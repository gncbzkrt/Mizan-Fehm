package com.mizan.fehm;
import android.app.Activity;
import android.content.*;
import android.net.Uri;
import org.json.JSONObject;
import java.io.*;
import java.text.SimpleDateFormat;
import java.util.*;

final class DriveBackup {
    static final int EXPORT=6101,IMPORT=6102;
    static void chooseExport(Activity a){Intent i=new Intent(Intent.ACTION_CREATE_DOCUMENT);i.addCategory(Intent.CATEGORY_OPENABLE);i.setType("application/json");i.putExtra(Intent.EXTRA_TITLE,"FEHM-Yedek-"+new SimpleDateFormat("yyyyMMdd-HHmm",Locale.US).format(new Date())+".json");a.startActivityForResult(i,EXPORT);}
    static void chooseImport(Activity a){Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);i.addCategory(Intent.CATEGORY_OPENABLE);i.setType("application/json");a.startActivityForResult(i,IMPORT);}
    static void exportTo(Context c,Uri uri)throws Exception{OutputStream out=c.getContentResolver().openOutputStream(uri,"w");if(out==null)throw new IOException("Yedek dosyası açılamadı.");String s=FehmStore.get(c).exportState().toString(2);out.write(s.getBytes("UTF-8"));out.flush();out.close();}
    static void importFrom(Context c,Uri uri)throws Exception{InputStream in=c.getContentResolver().openInputStream(uri);if(in==null)throw new IOException("Yedek okunamadı.");BufferedReader r=new BufferedReader(new InputStreamReader(in,"UTF-8"));StringBuilder b=new StringBuilder();String line;while((line=r.readLine())!=null)b.append(line);r.close();FehmStore.get(c).importState(new JSONObject(b.toString()));}
    private DriveBackup(){}
}
