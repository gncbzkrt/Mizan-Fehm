# FEHM v1.0.0 — Kur’an’ı Duy, Oku, Çöz ve Anla

Bu paket sıfır bilgiyle başlayan Türkçe kullanıcı için tek-vücut Kur’an Arapçası eğitim sistemidir.

## Eğitim omurgası
- Bugünkü Karma Ders: Elif-Bâ + 5 kelime + dinleme + mikro gramer + ayet laboratuvarı
- Duyduğunu Anla: önce ses, sonra Latin okunuş, en son meal
- Gördüğünü Oku: Elif-Bâ ve harekeler, fakat Latin destek hiçbir zaman zorla kapatılmaz
- Kelime & Kök: aralıklı tekrar ve aktif hatırlama
- Gramer: örnekten kurala, küçük parçalarla
- Kur’an Laboratuvarı: Arapça + Latin + Diyanet + Elmalılı + Diyanet Vakfı + FEHM AI analizi
- İlerleme: kelime ve okuma seviyeleri cihazda saklanır

## Bilimsel yöntemlerin uygulamadaki karşılığı
- Spaced repetition: FehmStore.review() aralığı başarıya göre büyütür
- Retrieval practice: anlam önce gizlenir, kullanıcı tahmin eder
- Contextual learning: kelime gerçek ayet ve kök ailesiyle gösterilir
- Interleaving: günlük derste okuma/kelime/dinleme/gramer karıştırılır
- Comprehensible input: sıfır seviyede Latin + Türkçe destek açık
- Error-driven learning: zor işaretlenen kelimeler tekrar kuyruğuna girer

## Kur’an verisi ve ses
- Ayet: Al Quran Cloud API (quran-uthmani + tr.transliteration + tr.diyanet + tr.yazir + tr.vakfi)
- Ses: Al Quran Cloud açık CDN, Mishary Alafasy 64 kbps ayet bazlı
- Daha önce açılan ayetler cihaz cache’inde tutulur.

## Drive yedeği
Ayarlar > Drive’a / Dosyaya Yedekle.
Android dosya seçicisinde Google Drive seçilirse yedek doğrudan Drive’a kaydedilir. Geri yüklemede aynı dosya seçilir.
Yedek: ders ilerlemesi, kelime ustalık seviyeleri, tekrar takvimi, oturumlar ve ayarlar. Gemini API anahtarı güvenlik nedeniyle yedeğe dahil edilmez.

## Windows kurulumu
1. ZIP’i çıkar.
2. build.bat çalıştır.
3. output/FEHM-v1.0.0-TAM-EGITIM-SISTEMI.apk oluşur.
4. Telefona kur.

Gerekenler: Android SDK Platform 35 + Build Tools 35.0.0 ve Android Studio JBR/JDK.

## Bilgisayarsız / telefondan APK oluşturma
Ana yol GitHub Actions’tır; telefonda GitHub uygulaması veya tarayıcı yeterlidir.
1. GitHub’da PRIVATE repo oluştur.
2. Bu klasörün içeriğini repoya yükle.
3. Actions > FEHM APK Oluştur > Run workflow.
4. Çalışma bitince FEHM-v1.0.0-APK artifact’ını telefona indir.
5. APK’yı kur.

ÖNEMLİ: signing/fehm-release.jks gelecekteki güncellemelerin aynı uygulamanın üzerine kurulabilmesi için korunmalıdır. Repo PRIVATE tutulmalıdır.

## Gemini
Ayarlar bölümüne kişisel Gemini API anahtarı girilir. AI yalnız öğretmen/çözümleyici katmandır; Kur’an metni ve mealler AI tarafından üretilmez.

## Mimari
- Bulut veritabanı yok
- Firebase yok
- Apps Script yok
- Spreadsheet yok
- Öğrenme verisi: fehm_personal.db
- Drive: yalnız yedek / geri yükleme
