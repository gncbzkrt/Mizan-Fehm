# FEHM v1.1.0 — Tam Öğrenme Sistemi

**Kur’an’ı duy · oku · çöz · anla.**

Bu sürüm sıfır bilgiyle başlayan Türkçe kullanıcı için FEHM’in ilk toplu öğrenme güncellemesidir. v1.0.1’de çalışan çekirdek korunmuş, gerçek kullanım testlerinde konuşulan UX ve öğretim iyileştirmeleri tek pakette birleştirilmiştir.

## v1.1.0’da toplu olarak eklenenler

### 1) Dinle ekranı
- Sure ve ayet kutularının ne olduğu açıkça yazılır.
- Seçili ayet artık **Fâtiha 1/1** gibi sure adıyla görünür.
- **Sure adından seç** penceresi: isim veya numara yazarak arama yapılabilir.
- Son dinlenen ayet hatırlanır.
- **Son Dinlenen** kısayolu vardır.
- **Bugünün Önerisi** kısayolu vardır.
- Dinleme çözümünden ayeti tek dokunuşla **Kur’an Laboratuvarında Aç** seçeneği vardır.
- Dinleme ilerlemesi beceri haritasına işlenir.

### 2) Kelime öğrenme
- KARIŞTIRDIM / BİLDİM düğmeleri cevap açılana kadar görünmez.
- ANLAMI GÖSTER’e basınca düğme kaybolur ve karar düğmeleri açılır.
- Kök ve anlam ailesi ayrı gösterilir.
- İlk temel kelimelerde gerçek Kur’an örneği + Latin okunuş + Türkçe anlam + kısa hafıza ipucu vardır.
- Karıştırılan kelime ertesi güne itilmek yerine yaklaşık 10 dakika sonra tekrar için uygun hale gelir.
- BİLDİM cevabında cevap süresi de dikkate alınır: hızlı hatırlama daha güçlü, uzun tereddüt daha temkinli puanlanır.
- Günlük 5 kelimede zamanı gelen tekrarlar yeni kelimelerden önce gelir.

### 3) FEHM AI — iyi bilen değil, iyi öğreten hoca
Kur’an Laboratuvarında artık iki katman vardır:

**BANA ŞİMDİ ÖĞRET**
- az bilgi,
- en fazla birkaç kelime,
- bir kök,
- tek mini gramer,
- “duyunca yakala” özeti,
- mini aktif hatırlama sorusu.

**DERİNLEŞTİR**
- kelime ve ses,
- doğrulanmış kök/anlam ailesi,
- gramer örüntüsü,
- meal farkları ve bağlam,
- kendi cümlenle anlam kurma,
- kesin dil verisi ile yorumun sınırı.

AI çıktısı artık Markdown işaretleriyle (`###`, `**`, vb.) ekrana basılmaz. JSON tabanlı bölümler gerçek uygulama başlıkları olarak çizilir; JSON üretimi bozulursa Markdown temizlenmiş sade metne düşer.

### 4) Kaynak güvenliği / dilbilgisel sınır
- AI kök ve morfolojiyi serbestçe tahmin etmemesi için sınırlandırılmıştır.
- Uygulamanın yerel kelime/kök verisi ayet analizine temel veri olarak verilir.
- Yerel doğrulama bulunmayan kök için AI’nın kesin hüküm vermemesi istenir.
- `ism` kelimesindeki klasik kök/etimoloji ihtilafı tek görüşmüş gibi sunulmaz.
- Dil analizi, meal tercihi ve yorum/tefsir birbirinden ayrılır.

### 5) Seviye ile büyüyen öğretmen
FEHM AI, uygulamadaki okuma + kelime + gramer ilerlemesinden bir öğretim seviyesi çıkarır:
- Sıfır / Başlangıç
- Temel
- Orta
- İleri

Aynı ayeti ileride tekrar açtığında öğretim dili seviyenle birlikte derinleşebilir.

### 6) Elif-Bâ / Okuma
- Latin destek zorunlu olarak kapanmaz.
- Harflerin yanında hareke bölümü de gösterilir.
- Amaç “önce bütün Arapçayı bitir, sonra Kur’an’a geç” değildir; dinleme ve anlama paralel yürür.

### 7) Tekrar & Mini Sınav
Öğren menüsüne **Tekrar & Mini Sınav** eklendi.
- zamanı gelen / karıştırılan kelimeler önce gelir,
- 5 soruluk aktif hatırlama testi,
- yanlış cevap tekrar kuyruğuna,
- doğru cevap ustalık sistemine işlenir,
- oturum sonucu yerel geçmişe kaydedilir.

### 8) İlerleme
Beceri haritası:
- Okuma / Elif-Bâ
- Kelime
- Dinleme
- Gramer
- Ayet Çözümleme

### 9) Drive yedeği
Manuel tarihli yedek ve geri yüklemeye ek olarak:
- **Otomatik Yedeği Kur** ile Drive/dosya konumu bir kez seçilebilir.
- URI izni cihazda kalıcı olarak saklanır.
- FEHM yaklaşık 12 saatten eski yedeği uygun açılış/öğrenme noktalarında sessizce güncellemeyi dener.
- **Otomatik Yedeği Şimdi Güncelle** düğmesi vardır.
- Telefon değişiminde yedekten geri yükleme ile öğrenme durumu korunur.
- Gemini API anahtarı yedeğe yazılmaz.

## Eğitim omurgası
- Retrieval practice / aktif hatırlama
- Spaced repetition / aralıklı tekrar
- Error-driven learning / hata tabanlı tekrar
- Contextual learning / gerçek ayet bağlamı
- Interleaving / günlük karma beceri eğitimi
- Comprehensible input / Latin + Türkçe destek
- Progressive disclosure / önce az, sonra derin bilgi

## Kur’an verisi ve ses
- Ayet: Al Quran Cloud API
  - quran-uthmani
  - tr.transliteration
  - tr.diyanet
  - tr.yazir
  - tr.vakfi
- Ses: Mishary Alafasy ayet bazlı açık CDN
- Açılan ayetler cihaz cache’inde saklanır.

## Mevcut uygulamanın üzerine kurulum
Paket aynı `com.mizan.fehm` kimliğini ve aynı `signing/fehm-release.jks` anahtarını korur. APK aynı keystore ile derlendiğinde v1.0.x uygulamasının üzerine güncelleme olarak kurulabilir.

## GitHub — telefondan, bilgisayarsız
Mevcut GitHub deponda ZIP’i tek dosya olarak tutuyorsan kullandığımız “ZIP’i aç → build.sh bul → derle” workflow’u bu paketle de uyumludur.

En kolay güncelleme:
1. Repodaki eski `FEHM-....zip` dosyasını sil veya yenisiyle değiştir.
2. `FEHM-v1.1.0-TAM-OGRENME-SISTEMI-Windows-Phone-Cloud.zip` dosyasını repo köküne yükle.
3. Mevcut `.github/workflows/build-apk.yml` dosyana dokunma.
4. Actions > FEHM APK Oluştur > Run workflow.
5. Yeşil tamamlanınca Artifacts bölümünden APK paketini indir.
6. İçindeki `FEHM-v1.1.0-TAM-OGRENME-SISTEMI.apk` dosyasını kur.

## Windows
ZIP’i çıkar → `build.bat`.
Çıktı:
`output/FEHM-v1.1.0-TAM-OGRENME-SISTEMI.apk`

## Mimari
- Firebase yok
- Apps Script yok
- Google Sheet yok
- ana öğrenme verisi cihazda: `fehm_personal.db`
- Drive: yedek / geri yükleme
- Gemini: öğretmen ve açıklama katmanı
- Kur’an metni/mealleri AI tarafından üretilmez
