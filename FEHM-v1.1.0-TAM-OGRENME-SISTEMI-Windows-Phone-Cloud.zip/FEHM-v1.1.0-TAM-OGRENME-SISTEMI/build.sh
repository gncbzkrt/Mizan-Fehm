#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")" && pwd)"; SDK="${ANDROID_SDK_ROOT:-${ANDROID_HOME:-$HOME/Android/Sdk}}"; BT="$SDK/build-tools/35.0.0"; PLATFORM="$SDK/platforms/android-35/android.jar"; BUILD="$ROOT/build"; OUT="$ROOT/output"; KS="$ROOT/signing/fehm-release.jks"; PASS='FehmKisisel2026'; ALIAS='fehm'
rm -rf "$BUILD"; mkdir -p "$BUILD/gen" "$BUILD/classes" "$BUILD/dex" "$OUT" "$ROOT/signing"
"$BT/aapt2" compile --dir "$ROOT/res" -o "$BUILD/resources.zip"
"$BT/aapt2" link -I "$PLATFORM" --manifest "$ROOT/AndroidManifest.xml" --java "$BUILD/gen" --min-sdk-version 23 --target-sdk-version 35 --version-code 2 --version-name 1.1.0 -A "$ROOT/assets" -o "$BUILD/base.apk" "$BUILD/resources.zip"
find "$ROOT/src" "$BUILD/gen" -name '*.java' -print0 | xargs -0 javac -encoding UTF-8 -source 8 -target 8 -bootclasspath "$PLATFORM" -d "$BUILD/classes"
(cd "$BUILD/classes" && jar cf "$BUILD/classes.jar" .)
"$BT/d8" --lib "$PLATFORM" --min-api 23 --output "$BUILD/dex" "$BUILD/classes.jar"
cp "$BUILD/base.apk" "$BUILD/with-dex.apk"; jar uf "$BUILD/with-dex.apk" -C "$BUILD/dex" classes.dex
"$BT/zipalign" -f -p 4 "$BUILD/with-dex.apk" "$BUILD/aligned.apk"
if [ ! -f "$KS" ]; then keytool -genkeypair -noprompt -keystore "$KS" -storepass "$PASS" -keypass "$PASS" -alias "$ALIAS" -keyalg RSA -keysize 2048 -validity 10000 -dname 'CN=FEHM Kisisel, OU=Kisisel, O=FEHM, C=TR'; fi
"$BT/apksigner" sign --ks "$KS" --ks-key-alias "$ALIAS" --ks-pass "pass:$PASS" --key-pass "pass:$PASS" --out "$OUT/FEHM-v1.1.0-TAM-OGRENME-SISTEMI.apk" "$BUILD/aligned.apk"
"$BT/apksigner" verify --verbose "$OUT/FEHM-v1.1.0-TAM-OGRENME-SISTEMI.apk"; echo "APK: $OUT/FEHM-v1.1.0-TAM-OGRENME-SISTEMI.apk"
