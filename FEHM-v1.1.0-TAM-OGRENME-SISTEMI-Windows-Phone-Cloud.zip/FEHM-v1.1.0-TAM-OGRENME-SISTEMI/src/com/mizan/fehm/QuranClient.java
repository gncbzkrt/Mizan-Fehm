package com.mizan.fehm;
import android.content.*;
import org.json.*;
import java.io.*;
import java.net.*;

final class QuranClient {
    static final class Ayah {int surah,ayah,global;String arabic="",latin="",diyanet="",elmalili="",vakif="";boolean ok(){return !arabic.isEmpty()&&!diyanet.isEmpty();}}
    static Ayah fetch(Context c,int surah,int ayah)throws Exception{surah=Math.max(1,Math.min(114,surah));ayah=Math.max(1,ayah);String key=surah+":"+ayah;SharedPreferences p=c.getSharedPreferences("fehm_quran_cache",Context.MODE_PRIVATE);String raw=p.getString(key,"");if(!raw.isEmpty()){try{return parse(new JSONObject(raw));}catch(Exception ignored){}}
        String u="https://api.alquran.cloud/v1/ayah/"+surah+":"+ayah+"/editions/quran-uthmani,tr.transliteration,tr.diyanet,tr.yazir,tr.vakfi";HttpURLConnection h=(HttpURLConnection)new URL(u).openConnection();h.setConnectTimeout(10000);h.setReadTimeout(25000);h.setRequestProperty("User-Agent","FEHM/1.1");int code=h.getResponseCode();if(code<200||code>=300)throw new IOException("Kur’an servisi HTTP "+code);BufferedReader r=new BufferedReader(new InputStreamReader(h.getInputStream(),"UTF-8"));StringBuilder b=new StringBuilder();String line;while((line=r.readLine())!=null)b.append(line);r.close();h.disconnect();JSONObject root=new JSONObject(b.toString());JSONArray a=root.optJSONArray("data");if(a==null)throw new IOException("Ayet verisi gelmedi.");Ayah x=new Ayah();x.surah=surah;x.ayah=ayah;for(int i=0;i<a.length();i++){JSONObject o=a.optJSONObject(i);if(o==null)continue;if(x.global==0)x.global=o.optInt("number",0);JSONObject ed=o.optJSONObject("edition");String id=ed==null?"":ed.optString("identifier");String t=o.optString("text","").trim();if("quran-uthmani".equals(id))x.arabic=t;else if("tr.transliteration".equals(id))x.latin=t;else if("tr.diyanet".equals(id))x.diyanet=t;else if("tr.yazir".equals(id))x.elmalili=t;else if("tr.vakfi".equals(id))x.vakif=t;}if(!x.ok())throw new IOException("Ayet metni eksik geldi.");JSONObject save=new JSONObject().put("surah",x.surah).put("ayah",x.ayah).put("global",x.global).put("arabic",x.arabic).put("latin",x.latin).put("diyanet",x.diyanet).put("elmalili",x.elmalili).put("vakif",x.vakif);p.edit().putString(key,save.toString()).apply();return x;}
    private static Ayah parse(JSONObject o){Ayah x=new Ayah();x.surah=o.optInt("surah");x.ayah=o.optInt("ayah");x.global=o.optInt("global");x.arabic=o.optString("arabic");x.latin=o.optString("latin");x.diyanet=o.optString("diyanet");x.elmalili=o.optString("elmalili");x.vakif=o.optString("vakif");return x;}
    static String audioUrl(Ayah a){return "https://cdn.islamic.network/quran/audio/64/ar.alafasy/"+a.global+".mp3";}
    private QuranClient(){}
}
