package com.mizan.fehm;

import android.app.*;
import android.content.*;
import android.graphics.*;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.text.*;
import android.view.*;
import android.widget.*;
import org.json.*;
import java.util.*;

public class MainActivity extends Activity {
    private static final int BG=Color.rgb(7,29,27), PANEL=Color.rgb(15,52,47), PANEL2=Color.rgb(22,68,60), GOLD=Color.rgb(220,184,91), TEXT=Color.rgb(242,247,244), MUTED=Color.rgb(166,192,180), GOOD=Color.rgb(61,145,104), BAD=Color.rgb(153,72,72);
    private LinearLayout root,nav;
    private final AudioEngine audio=new AudioEngine();
    private int page=0;
    private long wordShownAt=0L;

    private int dp(float v){return Math.round(v*getResources().getDisplayMetrics().density);}

    @Override protected void onCreate(Bundle b){
        super.onCreate(b);
        getWindow().setStatusBarColor(BG);getWindow().setNavigationBarColor(BG);
        showHome();
        DriveBackup.maybeAutoBackup(this);
    }
    @Override protected void onDestroy(){audio.stop();super.onDestroy();}

    private void shell(String eyebrow,String title,int active){
        page=active;
        LinearLayout outer=new LinearLayout(this);outer.setOrientation(LinearLayout.VERTICAL);outer.setBackgroundColor(BG);
        ScrollView sc=new ScrollView(this);LinearLayout body=new LinearLayout(this);body.setOrientation(LinearLayout.VERTICAL);body.setPadding(dp(14),dp(16),dp(14),dp(30));
        sc.addView(body,new ScrollView.LayoutParams(-1,-2));outer.addView(sc,new LinearLayout.LayoutParams(-1,0,1));root=body;
        LinearLayout h=new LinearLayout(this);h.setGravity(Gravity.CENTER_VERTICAL);ImageView icon=new ImageView(this);icon.setImageResource(R.mipmap.ic_launcher);h.addView(icon,new LinearLayout.LayoutParams(dp(48),dp(48)));
        LinearLayout tt=new LinearLayout(this);tt.setOrientation(LinearLayout.VERTICAL);tt.addView(tv(eyebrow.toUpperCase(new Locale("tr","TR")),10,GOLD,Typeface.BOLD),full());
        TextView titleV=tv(title,25,TEXT,Typeface.BOLD);titleV.setTypeface(Typeface.create(Typeface.SERIF,Typeface.BOLD));tt.addView(titleV,full());LinearLayout.LayoutParams tp=new LinearLayout.LayoutParams(0,-2,1);tp.leftMargin=dp(12);h.addView(tt,tp);body.addView(h,full());
        View r=new View(this);r.setBackgroundColor(Color.argb(80,220,184,91));LinearLayout.LayoutParams rp=new LinearLayout.LayoutParams(-1,dp(1));rp.topMargin=dp(13);rp.bottomMargin=dp(13);body.addView(r,rp);
        nav=new LinearLayout(this);nav.setBackgroundColor(Color.rgb(9,40,36));nav.setPadding(dp(4),dp(6),dp(4),dp(6));
        addNav("⌂","Bugün",0);addNav("♪","Dinle",1);addNav("ا","Oku",2);addNav("✦","Öğren",3);addNav("↗","İlerleme",4);
        outer.addView(nav,new LinearLayout.LayoutParams(-1,dp(66)));setContentView(outer);
    }
    private void addNav(String icon,String label,final int id){
        LinearLayout x=new LinearLayout(this);x.setOrientation(LinearLayout.VERTICAL);x.setGravity(Gravity.CENTER);x.addView(center(tv(icon,18,id==page?GOLD:MUTED,Typeface.NORMAL)),full());x.addView(center(tv(label,10,id==page?GOLD:MUTED,id==page?Typeface.BOLD:Typeface.NORMAL)),full());
        if(id==page)x.setBackground(round(PANEL2,GOLD,1,14));
        x.setOnClickListener(new View.OnClickListener(){public void onClick(View v){if(id==0)showHome();else if(id==1)showListen();else if(id==2)showRead();else if(id==3)showLearn();else showProgress();}});
        LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(0,-1,1);p.leftMargin=dp(2);p.rightMargin=dp(2);nav.addView(x,p);
    }

    private void showHome(){
        shell("Kur’an’ı duy · oku · çöz · anla","FEHM · Bugünkü Ders",0);
        LinearLayout hero=card();hero.addView(tv("Sıfırdan başlıyoruz",12,GOLD,Typeface.BOLD),full());hero.addView(tv("Her gün 10–15 dakika: biraz harf, biraz kelime, biraz dinleme, biraz gramer ve gerçek ayet. Hiçbir ön bilgi varsayılmaz.",15,TEXT,Typeface.NORMAL),space(8));
        Button start=button("BUGÜNKÜ KARMA DERSE BAŞLA");start.setOnClickListener(new View.OnClickListener(){public void onClick(View v){showDailyLesson();}});hero.addView(start,height(48,12));root.addView(hero,cardLp());
        int[] sug=QuranMeta.suggestion();LinearLayout suggested=card();suggested.addView(tv("BUGÜNÜN DİNLEME ÖNERİSİ",11,GOLD,Typeface.BOLD),full());suggested.addView(tv(QuranMeta.label(sug[0],sug[1]),18,TEXT,Typeface.BOLD),space(6));suggested.addView(tv("Önce yalnız dinle; bildiğin sesleri yakala. Sonra laboratuvarda çöz.",13,MUTED,Typeface.NORMAL),space(5));
        final int ss=sug[0],sa=sug[1];Button open=button("DİNLEYEREK BAŞLA");open.setOnClickListener(new View.OnClickListener(){public void onClick(View v){loadAyahAndPlay(ss,sa,true,null);}});suggested.addView(open,height(44,10));root.addView(suggested,cardLp());
        LinearLayout stats=card();stats.addView(tv("BUGÜNKÜ YOL",11,GOLD,Typeface.BOLD),full());stats.addView(tv("1 · Harfi gör ve sesi tanı\n2 · 5 temel kelime\n3 · Bir ayeti yalnız dinle\n4 · Mini gramer\n5 · Ayeti Latin okunuşla takip et\n6 · Anlamı tahmin et ve mealle karşılaştır\n7 · Zorlandıklarını tekrar kuyruğuna gönder",14,TEXT,Typeface.NORMAL),space(8));root.addView(stats,cardLp());
    }

    private void showDailyLesson(){
        final CourseData d=CourseData.get(this);final FehmStore s=FehmStore.get(this);shell("Uyarlanabilir karma eğitim","FEHM · Günlük Ders",0);
        final int li=s.getInt("letterIndex",0)%Math.max(1,d.letters.size());final CourseData.Letter l=d.letters.get(li);LinearLayout c=card();c.addView(tv("1 / OKUMA",10,GOLD,Typeface.BOLD),full());c.addView(center(tv(l.arabic,46,TEXT,Typeface.BOLD)),space(6));c.addView(center(tv(l.name.toUpperCase(new Locale("tr","TR"))+" · "+l.sound,16,TEXT,Typeface.BOLD)),full());c.addView(tv(l.note+"\nÖrnek: "+l.example,14,MUTED,Typeface.NORMAL),space(8));
        Button learned=button("TANIDIM · DEVAM");learned.setOnClickListener(new View.OnClickListener(){public void onClick(View v){s.put("letterIndex",""+(li+1));prepareDailyWords();showDailyWords(0);}});c.addView(learned,height(46,12));root.addView(c,cardLp());
    }
    private void prepareDailyWords(){
        CourseData d=CourseData.get(this);FehmStore s=FehmStore.get(this);ArrayList<String> ids=new ArrayList<String>();ArrayList<String> due=s.due("word",5);for(String id:due)if(findWord(id)!=null&&!ids.contains(id))ids.add(id);
        int cursor=s.getInt("wordCursor",0),guard=0;while(ids.size()<5&&guard<d.words.size()*2){CourseData.Word w=d.words.get((cursor+guard)%d.words.size());if(!ids.contains(w.id))ids.add(w.id);guard++;}
        StringBuilder b=new StringBuilder();for(String id:ids){if(b.length()>0)b.append(',');b.append(id);}s.put("daily_words",b.toString());
    }
    private CourseData.Word findWord(String id){for(CourseData.Word w:CourseData.get(this).words)if(w.id.equals(id))return w;return null;}
    private CourseData.Word dailyWord(int idx){
        FehmStore s=FehmStore.get(this);String raw=s.get("daily_words","");if(raw.isEmpty()){prepareDailyWords();raw=s.get("daily_words","");}String[] ids=raw.split(",");if(idx>=0&&idx<ids.length){CourseData.Word w=findWord(ids[idx]);if(w!=null)return w;}CourseData d=CourseData.get(this);return d.words.get((s.getInt("wordCursor",0)+idx)%d.words.size());
    }
    private void showDailyWords(final int idx){
        if(idx>=5){FehmStore.get(this).put("daily_words","");showDailyListen();return;}
        final CourseData.Word w=dailyWord(idx);shell("Geri çağırma + aralıklı tekrar","FEHM · Kelime "+(idx+1)+"/5",0);wordShownAt=System.currentTimeMillis();
        final LinearLayout c=card();c.addView(center(tv(w.arabic,35,TEXT,Typeface.BOLD)),full());c.addView(center(tv(w.latin,18,GOLD,Typeface.BOLD)),space(6));
        final TextView prompt=tv("Önce tahmin et. Hazır olduğunda anlamı aç.",14,MUTED,Typeface.NORMAL);c.addView(prompt,space(10));
        final LinearLayout details=new LinearLayout(this);details.setOrientation(LinearLayout.VERTICAL);details.setVisibility(View.GONE);c.addView(details,space(8));
        final Button reveal=button("ANLAMI GÖSTER");c.addView(reveal,height(44,10));
        final LinearLayout row=new LinearLayout(this);final Button hard=smallButton("KARIŞTIRDIM",BAD);final Button ok=smallButton("BİLDİM",GOOD);row.addView(hard,new LinearLayout.LayoutParams(0,dp(46),1));LinearLayout.LayoutParams op=new LinearLayout.LayoutParams(0,dp(46),1);op.leftMargin=dp(8);row.addView(ok,op);row.setVisibility(View.GONE);c.addView(row,space(10));
        reveal.setOnClickListener(new View.OnClickListener(){public void onClick(View v){
            prompt.setText(w.meaning);prompt.setTextColor(TEXT);details.setVisibility(View.VISIBLE);details.removeAllViews();
            details.addView(tv("KÖK / AİLE",10,GOLD,Typeface.BOLD),full());details.addView(tv(w.root+"\n"+w.family,13,MUTED,Typeface.NORMAL),space(4));
            if(w.exampleArabic!=null&&!w.exampleArabic.isEmpty()){
                details.addView(tv("KUR’AN ÖRNEĞİ",10,GOLD,Typeface.BOLD),space(10));TextView exAr=tv(w.exampleArabic,22,TEXT,Typeface.BOLD);exAr.setGravity(Gravity.RIGHT);details.addView(exAr,space(4));details.addView(tv(w.exampleLatin,14,GOLD,Typeface.BOLD),space(3));details.addView(tv(w.exampleMeaning,13,TEXT,Typeface.NORMAL),space(3));
            }
            if(w.hint!=null&&!w.hint.isEmpty()){details.addView(tv("KISA İPUCU",10,GOLD,Typeface.BOLD),space(10));details.addView(tv(w.hint,13,MUTED,Typeface.NORMAL),space(4));}
            reveal.setVisibility(View.GONE);row.setVisibility(View.VISIBLE);
        }});
        hard.setOnClickListener(new View.OnClickListener(){public void onClick(View v){FehmStore.get(MainActivity.this).review("word",w.id,2);DriveBackup.maybeAutoBackup(MainActivity.this);showDailyWords(idx+1);}});
        ok.setOnClickListener(new View.OnClickListener(){public void onClick(View v){long sec=(System.currentTimeMillis()-wordShownAt)/1000L;int q=sec<=10?5:(sec<=25?4:3);FehmStore.get(MainActivity.this).review("word",w.id,q);DriveBackup.maybeAutoBackup(MainActivity.this);showDailyWords(idx+1);}});
        root.addView(c,cardLp());
    }
    private void showDailyListen(){shell("Önce kulak · sonra metin","FEHM · Dinleme",0);LinearLayout c=card();c.addView(tv("3 / DİNLE",10,GOLD,Typeface.BOLD),full());c.addView(tv("Fâtiha 1/1’i bir kez yalnız dinle. Kelimeleri çözmeye çalışma; tanıdığın sesleri yakalamaya çalış.",14,TEXT,Typeface.NORMAL),space(8));Button b=button("AYETİ DİNLE");b.setOnClickListener(new View.OnClickListener(){public void onClick(View v){loadAyahAndPlay(1,1,false,new Runnable(){public void run(){showDailyGrammar();}});}});c.addView(b,height(48,12));root.addView(c,cardLp());}
    private void showDailyGrammar(){
        CourseData d=CourseData.get(this);final int gi=FehmStore.get(this).getInt("grammarIndex",0)%d.grammar.size();final CourseData.Grammar g=d.grammar.get(gi);shell("Kuralı ezberleme · örüntüyü fark et","FEHM · Mini Gramer",0);LinearLayout c=card();c.addView(tv("4 / GRAMER",10,GOLD,Typeface.BOLD),full());c.addView(tv(g.title,22,TEXT,Typeface.BOLD),space(8));c.addView(tv(g.meaning,16,GOLD,Typeface.BOLD),space(4));c.addView(tv(g.body+"\n\nÖrnek: "+g.example,14,TEXT,Typeface.NORMAL),space(8));Button next=button("AYET ÜZERİNDE BİRLEŞTİR");next.setOnClickListener(new View.OnClickListener(){public void onClick(View v){FehmStore s=FehmStore.get(MainActivity.this);s.put("grammarIndex",""+(gi+1));s.put("wordCursor",""+(s.getInt("wordCursor",0)+5));DriveBackup.maybeAutoBackup(MainActivity.this);showLab(1,1,true);}});c.addView(next,height(46,12));root.addView(c,cardLp());
    }

    private void showListen(){
        shell("Duyduğunu anlamaya çalış","FEHM · Dinle",1);addVerseChooser(true);
        LinearLayout c=card();c.addView(tv("DİNLEME METODU",11,GOLD,Typeface.BOLD),full());c.addView(tv("1. Önce metni görmeden dinle.\n2. Duyduğun tanıdık kelimeleri zihninden seç.\n3. Sonra Latin okunuşu aç.\n4. En son Türkçe anlamı gör.\n5. Aynı ayeti tekrar dinle.",14,TEXT,Typeface.NORMAL),space(8));root.addView(c,cardLp());
    }
    private void addVerseChooser(final boolean listen){
        final FehmStore st=FehmStore.get(this);LinearLayout c=card();c.addView(tv("AYET SEÇ",11,GOLD,Typeface.BOLD),full());
        int defS=listen?st.getInt("lastListenSurah",1):st.getInt("lastLabSurah",1),defA=listen?st.getInt("lastListenAyah",1):st.getInt("lastLabAyah",1);
        final TextView selected=tv(QuranMeta.label(defS,defA),18,TEXT,Typeface.BOLD);c.addView(selected,space(7));
        LinearLayout labels=new LinearLayout(this);TextView ls=tv("SURE NO",10,GOLD,Typeface.BOLD),la=tv("AYET NO",10,GOLD,Typeface.BOLD);labels.addView(ls,new LinearLayout.LayoutParams(0,-2,1));LinearLayout.LayoutParams lap=new LinearLayout.LayoutParams(0,-2,1);lap.leftMargin=dp(8);labels.addView(la,lap);c.addView(labels,space(10));
        final EditText s=input("Sure",String.valueOf(defS)),a=input("Ayet",String.valueOf(defA));s.setInputType(android.text.InputType.TYPE_CLASS_NUMBER);a.setInputType(android.text.InputType.TYPE_CLASS_NUMBER);
        LinearLayout row=new LinearLayout(this);row.addView(s,new LinearLayout.LayoutParams(0,dp(48),1));LinearLayout.LayoutParams ap=new LinearLayout.LayoutParams(0,dp(48),1);ap.leftMargin=dp(8);row.addView(a,ap);c.addView(row,space(5));
        TextWatcher watcher=new TextWatcher(){public void beforeTextChanged(CharSequence cs,int st,int c,int a){}public void onTextChanged(CharSequence cs,int st,int b,int c){int su=Math.max(1,Math.min(114,parse(s.getText().toString(),1))),ay=Math.max(1,parse(a.getText().toString(),1));selected.setText(QuranMeta.label(su,ay));}public void afterTextChanged(Editable e){}};s.addTextChangedListener(watcher);a.addTextChangedListener(watcher);
        Button picker=outlineButton("SURE ADINDAN SEÇ");picker.setOnClickListener(new View.OnClickListener(){public void onClick(View v){showSurahPicker(s,selected,a);}});c.addView(picker,height(42,9));
        if(listen){
            LinearLayout quick=new LinearLayout(this);Button last=outlineButton("SON DİNLENEN");Button sug=outlineButton("BUGÜNÜN ÖNERİSİ");quick.addView(last,new LinearLayout.LayoutParams(0,dp(42),1));LinearLayout.LayoutParams qp=new LinearLayout.LayoutParams(0,dp(42),1);qp.leftMargin=dp(8);quick.addView(sug,qp);c.addView(quick,space(8));
            last.setOnClickListener(new View.OnClickListener(){public void onClick(View v){s.setText(""+st.getInt("lastListenSurah",1));a.setText(""+st.getInt("lastListenAyah",1));}});
            sug.setOnClickListener(new View.OnClickListener(){public void onClick(View v){int[] p=QuranMeta.suggestion();s.setText(""+p[0]);a.setText(""+p[1]);}});
        }
        Button go=button(listen?"ÖNCE SADECE DİNLE":"AYETİ AÇ");go.setOnClickListener(new View.OnClickListener(){public void onClick(View v){int su=Math.max(1,Math.min(114,parse(s.getText().toString(),1))),ay=Math.max(1,parse(a.getText().toString(),1));if(listen)loadAyahAndPlay(su,ay,true,null);else showLab(su,ay,false);}});c.addView(go,height(48,10));root.addView(c,cardLp());
    }
    private void showSurahPicker(final EditText surahField,final TextView selected,final EditText ayahField){
        LinearLayout box=new LinearLayout(this);box.setOrientation(LinearLayout.VERTICAL);box.setPadding(dp(12),dp(8),dp(12),dp(8));final EditText search=new EditText(this);search.setHint("Sure adı veya numara ara");search.setSingleLine(true);box.addView(search,new LinearLayout.LayoutParams(-1,dp(52)));final ListView list=new ListView(this);final ArrayAdapter<String> ad=new ArrayAdapter<String>(this,android.R.layout.simple_list_item_1,new ArrayList<String>(Arrays.asList(QuranMeta.labels())));list.setAdapter(ad);box.addView(list,new LinearLayout.LayoutParams(-1,dp(360)));
        final AlertDialog dlg=new AlertDialog.Builder(this).setTitle("Sure seç").setView(box).setNegativeButton("Kapat",null).create();
        search.addTextChangedListener(new TextWatcher(){public void beforeTextChanged(CharSequence s,int st,int c,int a){}public void onTextChanged(CharSequence s,int st,int b,int c){ad.getFilter().filter(s);}public void afterTextChanged(Editable e){}});
        list.setOnItemClickListener(new AdapterView.OnItemClickListener(){public void onItemClick(AdapterView<?> p,View v,int pos,long id){String value=(String)p.getItemAtPosition(pos);int dot=value.indexOf('·');int su=parse(dot>0?value.substring(0,dot).trim():value,1);surahField.setText(""+su);ayahField.setText("1");selected.setText(QuranMeta.label(su,1));dlg.dismiss();}});dlg.show();
    }
    private void loadAyahAndPlay(final int surah,final int ayah,final boolean revealAfter,final Runnable after){
        Toast.makeText(this,"Ayet hazırlanıyor…",Toast.LENGTH_SHORT).show();new Thread(new Runnable(){public void run(){try{final QuranClient.Ayah x=QuranClient.fetch(MainActivity.this,surah,ayah);runOnUiThread(new Runnable(){public void run(){FehmStore s=FehmStore.get(MainActivity.this);s.put("lastListenSurah",""+surah);s.put("lastListenAyah",""+ayah);audio.play(QuranClient.audioUrl(x),new Runnable(){public void run(){Toast.makeText(MainActivity.this,QuranMeta.label(surah,ayah)+" · yalnız dinle",Toast.LENGTH_SHORT).show();}},new Runnable(){public void run(){runOnUiThread(new Runnable(){public void run(){if(revealAfter)showListeningReveal(x);if(after!=null)after.run();}});}},new AudioEngine.ErrorHandler(){public void onError(final String m){runOnUiThread(new Runnable(){public void run(){Toast.makeText(MainActivity.this,m,Toast.LENGTH_LONG).show();}});}});}});}catch(final Exception e){runOnUiThread(new Runnable(){public void run(){Toast.makeText(MainActivity.this,e.getMessage(),Toast.LENGTH_LONG).show();}});}}}).start();
    }
    private void showListeningReveal(final QuranClient.Ayah x){
        FehmStore s=FehmStore.get(this);s.put("listenScore",""+Math.min(100,s.getInt("listenScore",0)+2));s.session("listen",1,1,0);DriveBackup.maybeAutoBackup(this);
        shell("Şimdi sesi metne bağla","FEHM · "+QuranMeta.label(x.surah,x.ayah),1);LinearLayout c=card();c.addView(tv("ARAPÇA",10,GOLD,Typeface.BOLD),full());TextView ar=tv(x.arabic,28,TEXT,Typeface.BOLD);ar.setGravity(Gravity.RIGHT);c.addView(ar,space(7));c.addView(tv("LATİN HARFLİ OKUNUŞ",10,GOLD,Typeface.BOLD),space(12));c.addView(tv(x.latin,17,TEXT,Typeface.NORMAL),space(5));
        final Button meal=button("ANLAMI GÖSTER");final TextView m=tv("",15,TEXT,Typeface.NORMAL);meal.setOnClickListener(new View.OnClickListener(){public void onClick(View v){m.setText("Diyanet:\n"+x.diyanet+"\n\nElmalılı:\n"+x.elmalili);meal.setVisibility(View.GONE);}});c.addView(meal,height(44,12));c.addView(m,space(8));
        Button again=outlineButton("TEKRAR DİNLE");again.setOnClickListener(new View.OnClickListener(){public void onClick(View v){audio.play(QuranClient.audioUrl(x),null,null,null);}});c.addView(again,height(44,10));Button lab=button("AYETİ LABORATUVARDA AÇ");lab.setOnClickListener(new View.OnClickListener(){public void onClick(View v){showLab(x.surah,x.ayah,false);}});c.addView(lab,height(46,8));root.addView(c,cardLp());
    }

    private void showRead(){
        shell("Gördüğünü oku","FEHM · Elif-Bâ ve Okuma",2);final CourseData d=CourseData.get(this);final int idx=FehmStore.get(this).getInt("letterIndex",0)%Math.max(1,d.letters.size());LinearLayout intro=card();intro.addView(tv("ELİF-BÂ · ZORUNLU KAPI DEĞİL",11,GOLD,Typeface.BOLD),full());intro.addView(tv("Latin okunuş desteği her zaman açık kalabilir. Amaç Arap harflerini yavaş yavaş tanımak; Kur’an dinleme ve anlam çalışmasını durdurmak değil.",14,TEXT,Typeface.NORMAL),space(8));root.addView(intro,cardLp());
        for(int i=0;i<Math.min(6,d.letters.size());i++){int p=(idx+i)%d.letters.size();final CourseData.Letter l=d.letters.get(p);LinearLayout c=card();LinearLayout row=new LinearLayout(this);row.addView(center(tv(l.arabic,36,TEXT,Typeface.BOLD)),new LinearLayout.LayoutParams(dp(64),dp(58)));LinearLayout tx=new LinearLayout(this);tx.setOrientation(LinearLayout.VERTICAL);tx.addView(tv(l.name.toUpperCase(new Locale("tr","TR"))+" · "+l.sound,15,GOLD,Typeface.BOLD),full());tx.addView(tv(l.note+" · Örnek: "+l.example,13,MUTED,Typeface.NORMAL),space(4));row.addView(tx,new LinearLayout.LayoutParams(0,-2,1));c.addView(row,full());root.addView(c,cardLp());}
        if(!d.marks.isEmpty()){LinearLayout marks=card();marks.addView(tv("HAREKELER · SESİ DEĞİŞTİREN İŞARETLER",11,GOLD,Typeface.BOLD),full());for(int i=0;i<Math.min(4,d.marks.size());i++){CourseData.Letter m=d.marks.get(i);marks.addView(tv(m.arabic+"   "+m.name+" · "+m.sound+"\n"+m.note,14,TEXT,Typeface.NORMAL),space(7));}root.addView(marks,cardLp());}
        Button more=button("SONRAKİ HARFLER");more.setOnClickListener(new View.OnClickListener(){public void onClick(View v){FehmStore.get(MainActivity.this).put("letterIndex",""+(idx+6));DriveBackup.maybeAutoBackup(MainActivity.this);showRead();}});root.addView(more,height(48,12));
    }

    private void showLearn(){
        shell("Kelime · kök · gramer · ayet","FEHM · Öğren",3);
        addLearnCard("KELİME & KÖK","En sık karşılaşılan Kur’an kelimelerini kök aileleri, ayet örnekleri ve aralıklı tekrar ile öğren.",new View.OnClickListener(){public void onClick(View v){showWords();}});
        addLearnCard("GRAMER","Kuralları küçük parçalarda, önce örnek sonra kural yöntemiyle fark et.",new View.OnClickListener(){public void onClick(View v){showGrammar();}});
        addLearnCard("AYET ÇÖZÜMLEME · KUR’AN LABORATUVARI","Bir ayeti aç; Arapça, Latin okunuş, mealler, ses ve seviyene göre FEHM AI öğretimiyle incele.",new View.OnClickListener(){public void onClick(View v){showLabChooser();}});
        addLearnCard("TEKRAR & MİNİ SINAV","Önce zamanı gelen ve karıştırdığın kelimelerden başlayarak aktif hatırlama testi yap.",new View.OnClickListener(){public void onClick(View v){showQuiz();}});
    }
    private void addLearnCard(String title,String body,View.OnClickListener l){LinearLayout c=card();c.addView(tv(title,18,GOLD,Typeface.BOLD),full());c.addView(tv(body,14,TEXT,Typeface.NORMAL),space(7));Button b=button("AÇ");b.setOnClickListener(l);c.addView(b,height(44,10));root.addView(c,cardLp());}
    private void showWords(){
        shell("Aktif hatırlama + kök ailesi","FEHM · Kelimeler",3);final CourseData d=CourseData.get(this);final int cursor=FehmStore.get(this).getInt("freeWordCursor",0)%Math.max(1,d.words.size());
        for(int i=0;i<8;i++){final CourseData.Word w=d.words.get((cursor+i)%d.words.size());LinearLayout c=card();c.addView(tv(w.arabic+"   "+w.latin,22,TEXT,Typeface.BOLD),full());c.addView(tv(w.meaning,15,GOLD,Typeface.BOLD),space(6));c.addView(tv("Kök: "+w.root+"\nAile: "+w.family+"\nSeviye: "+FehmStore.get(this).level("word",w.id)+"/6",13,MUTED,Typeface.NORMAL),space(5));
            if(w.exampleArabic!=null&&!w.exampleArabic.isEmpty()){final TextView ex=tv("",13,TEXT,Typeface.NORMAL);Button eb=outlineButton("AYET ÖRNEĞİNİ GÖR");eb.setOnClickListener(new View.OnClickListener(){public void onClick(View v){ex.setText(w.exampleArabic+"\n"+w.exampleLatin+"\n"+w.exampleMeaning);v.setVisibility(View.GONE);}});c.addView(eb,height(40,8));c.addView(ex,space(5));}
            LinearLayout row=new LinearLayout(this);Button h=smallButton("ZOR",BAD),o=smallButton("KOLAY",GOOD);row.addView(h,new LinearLayout.LayoutParams(0,dp(42),1));LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(0,dp(42),1);p.leftMargin=dp(8);row.addView(o,p);h.setOnClickListener(new View.OnClickListener(){public void onClick(View v){FehmStore.get(MainActivity.this).review("word",w.id,2);Toast.makeText(MainActivity.this,"Bugünkü tekrar kuyruğuna alındı",Toast.LENGTH_SHORT).show();}});o.setOnClickListener(new View.OnClickListener(){public void onClick(View v){FehmStore.get(MainActivity.this).review("word",w.id,4);Toast.makeText(MainActivity.this,"İlerleme kaydedildi",Toast.LENGTH_SHORT).show();}});c.addView(row,space(9));root.addView(c,cardLp());
        }
        Button next=button("SONRAKİ KELİMELER");next.setOnClickListener(new View.OnClickListener(){public void onClick(View v){FehmStore.get(MainActivity.this).put("freeWordCursor",""+(cursor+8));showWords();}});root.addView(next,height(48,12));
    }
    private void showGrammar(){
        shell("Sarf-nahiv, ama sıfırdan","FEHM · Gramer",3);final CourseData d=CourseData.get(this);final int cursor=FehmStore.get(this).getInt("freeGrammarCursor",0)%Math.max(1,d.grammar.size());
        LinearLayout intro=card();intro.addView(tv("ÖNCE ÖRNEK · SONRA KURAL",11,GOLD,Typeface.BOLD),full());intro.addView(tv("Başlangıçta teknik isimleri ezberlemek zorunda değilsin. Aynı yapıyı ayetlerde tekrar gördükçe FEHM kuralın adını ve ayrıntısını kademeli olarak açar.",13,MUTED,Typeface.NORMAL),space(6));root.addView(intro,cardLp());
        for(int i=0;i<5;i++){CourseData.Grammar g=d.grammar.get((cursor+i)%d.grammar.size());LinearLayout c=card();c.addView(tv(g.title,19,GOLD,Typeface.BOLD),full());c.addView(tv(g.meaning,15,TEXT,Typeface.BOLD),space(5));c.addView(tv(g.body+"\n\nÖrnek: "+g.example,14,TEXT,Typeface.NORMAL),space(7));root.addView(c,cardLp());}
        Button next=button("SONRAKİ GRAMER DERSLERİ");next.setOnClickListener(new View.OnClickListener(){public void onClick(View v){FehmStore.get(MainActivity.this).put("freeGrammarCursor",""+(cursor+5));showGrammar();}});root.addView(next,height(48,12));
    }

    private void showQuiz(){
        CourseData d=CourseData.get(this);FehmStore st=FehmStore.get(this);final ArrayList<CourseData.Word> deck=new ArrayList<CourseData.Word>();ArrayList<String> due=st.due("word",5);for(String id:due){CourseData.Word w=findWord(id);if(w!=null&&!deck.contains(w))deck.add(w);}int cursor=st.getInt("quizCursor",0),g=0;while(deck.size()<5&&g<d.words.size()*2){CourseData.Word w=d.words.get((cursor+g)%d.words.size());if(!deck.contains(w))deck.add(w);g++;}showQuizQuestion(deck,0,0);
    }
    private void showQuizQuestion(final ArrayList<CourseData.Word> deck,final int idx,final int score){
        if(idx>=deck.size()){FehmStore st=FehmStore.get(this);st.session("word_quiz",score,deck.size(),0);st.put("quizCursor",""+(st.getInt("quizCursor",0)+deck.size()));DriveBackup.maybeAutoBackup(this);shell("Aktif hatırlama tamamlandı","FEHM · Mini Sınav",3);LinearLayout done=card();done.addView(tv("SONUÇ",11,GOLD,Typeface.BOLD),full());done.addView(center(tv(score+" / "+deck.size(),34,TEXT,Typeface.BOLD)),space(8));done.addView(tv(score==deck.size()?"Harika. Hepsini aktif olarak hatırladın.":"Yanlışların ve karıştırdıkların tekrar kuyruğuna alındı.",14,MUTED,Typeface.NORMAL),space(8));Button back=button("ÖĞREN MENÜSÜNE DÖN");back.setOnClickListener(new View.OnClickListener(){public void onClick(View v){showLearn();}});done.addView(back,height(44,12));root.addView(done,cardLp());return;}
        final CourseData.Word target=deck.get(idx);shell("Cevabı zihninden geri çağır","FEHM · Sınav "+(idx+1)+"/"+deck.size(),3);LinearLayout c=card();c.addView(center(tv(target.arabic,36,TEXT,Typeface.BOLD)),full());c.addView(center(tv(target.latin,17,GOLD,Typeface.BOLD)),space(5));c.addView(tv("Bu kelimenin temel anlamını seç.",14,MUTED,Typeface.NORMAL),space(10));
        final ArrayList<CourseData.Word> opts=new ArrayList<CourseData.Word>();opts.add(target);CourseData d=CourseData.get(this);int seed=(target.id.hashCode() & 0x7fffffff)+idx*31;int k=0;while(opts.size()<4&&k<d.words.size()*2){CourseData.Word w=d.words.get((seed+k)%d.words.size());if(!opts.contains(w)&&!w.meaning.equals(target.meaning))opts.add(w);k++;}Collections.shuffle(opts,new Random(seed));
        for(final CourseData.Word o:opts){Button b=outlineButton(o.meaning);b.setTextSize(11);b.setOnClickListener(new View.OnClickListener(){public void onClick(View v){boolean ok=o.id.equals(target.id);FehmStore.get(MainActivity.this).review("word",target.id,ok?5:2);Toast.makeText(MainActivity.this,ok?"Doğru":"Doğru cevap: "+target.meaning,Toast.LENGTH_SHORT).show();showQuizQuestion(deck,idx+1,score+(ok?1:0));}});c.addView(b,height(48,8));}root.addView(c,cardLp());
    }

    private void showLabChooser(){shell("Kelime kelime düşün","FEHM · Kur’an Laboratuvarı",3);addVerseChooser(false);}
    private void showLab(final int surah,final int ayah,final boolean fromDaily){
        FehmStore.get(this).put("lastLabSurah",""+surah);FehmStore.get(this).put("lastLabAyah",""+ayah);shell("Oku · çöz · karşılaştır · yorumla","FEHM · Ayet Laboratuvarı",3);final LinearLayout wait=card();wait.addView(tv(QuranMeta.label(surah,ayah)+" yükleniyor…",15,MUTED,Typeface.NORMAL),full());root.addView(wait,cardLp());
        new Thread(new Runnable(){public void run(){try{final QuranClient.Ayah x=QuranClient.fetch(MainActivity.this,surah,ayah);runOnUiThread(new Runnable(){public void run(){renderLab(x);}});}catch(final Exception e){runOnUiThread(new Runnable(){public void run(){wait.removeAllViews();wait.addView(tv(e.getMessage(),14,BAD,Typeface.NORMAL),full());}});}}}).start();
    }
    private void renderLab(final QuranClient.Ayah x){
        shell("Oku · çöz · karşılaştır · yorumla","FEHM · "+QuranMeta.label(x.surah,x.ayah),3);
        LinearLayout c=card();c.addView(tv("ARAPÇA",10,GOLD,Typeface.BOLD),full());TextView ar=tv(x.arabic,28,TEXT,Typeface.BOLD);ar.setGravity(Gravity.RIGHT);c.addView(ar,space(7));c.addView(tv("LATİN HARFLİ OKUNUŞ",10,GOLD,Typeface.BOLD),space(12));c.addView(tv(x.latin,17,TEXT,Typeface.NORMAL),space(5));c.addView(tv("DİYANET MEALİ",10,GOLD,Typeface.BOLD),space(12));c.addView(tv(x.diyanet,15,TEXT,Typeface.NORMAL),space(5));c.addView(tv("KARŞILAŞTIR",10,GOLD,Typeface.BOLD),space(12));c.addView(tv("Elmalılı: "+x.elmalili+"\n\nDiyanet Vakfı: "+x.vakif,13,MUTED,Typeface.NORMAL),space(5));Button listen=button("AYETİ DİNLE");listen.setOnClickListener(new View.OnClickListener(){public void onClick(View v){audio.play(QuranClient.audioUrl(x),null,null,null);}});c.addView(listen,height(44,12));root.addView(c,cardLp());
        final LinearLayout ai=card();int stage=learningStage();ai.addView(tv("FEHM AI · SEVİYENE GÖRE ÖĞRET",11,GOLD,Typeface.BOLD),full());ai.addView(tv("Öğretim seviyesi: "+stageName(stage)+". Önce az ve gerekli bilgiyi öğren; istersen sonra derine in.",13,MUTED,Typeface.NORMAL),space(7));
        final LinearLayout output=new LinearLayout(this);output.setOrientation(LinearLayout.VERTICAL);
        Button teach=button("BANA ŞİMDİ ÖĞRET");Button deep=outlineButton("DERİNLEŞTİR · KÖK + GRAMER + BAĞLAM");teach.setOnClickListener(new View.OnClickListener(){public void onClick(View v){runAiLesson(x,false,output);}});deep.setOnClickListener(new View.OnClickListener(){public void onClick(View v){runAiLesson(x,true,output);}});ai.addView(teach,height(46,10));ai.addView(deep,height(44,8));ai.addView(output,space(10));root.addView(ai,cardLp());
    }

    private int learningStage(){
        FehmStore s=FehmStore.get(this);CourseData d=CourseData.get(this);int letters=(int)(100.0*s.getInt("letterIndex",0)/Math.max(1,d.letters.size()));int words=(int)(100.0*s.learnedCount("word")/Math.max(1,d.words.size()));int grammar=(int)(100.0*s.getInt("grammarIndex",0)/Math.max(1,d.grammar.size()));int avg=(letters+words+grammar)/3;if(avg<20)return 0;if(avg<45)return 1;if(avg<70)return 2;return 3;
    }
    private String stageName(int s){return s==0?"Sıfır / Başlangıç":s==1?"Temel":s==2?"Orta":"İleri";}
    private String trustedFoundation(QuranClient.Ayah x){
        String verse=normalizeArabic(x.arabic);StringBuilder b=new StringBuilder();int count=0;for(CourseData.Word w:CourseData.get(this).words){String nw=normalizeArabic(w.arabic);if(nw.length()<1)continue;if(verse.contains(nw)){if(count++>=14)break;b.append("- ").append(w.arabic).append(" | ").append(w.latin).append(" | ").append(w.meaning).append(" | Kök/veri: ").append(w.root).append(" | Aile: ").append(w.family).append('\n');}}
        if(b.length()==0)b.append("Yerel sözlükte bu ayet için doğrulanmış eşleşme bulunamadı. Kök tahmini yapma.\n");return b.toString();
    }
    private String normalizeArabic(String s){if(s==null)return "";return s.replace("ـ","").replaceAll("[\\u064B-\\u065F\\u0670\\u06D6-\\u06ED]","").replace("ٱ","ا").replace("أ","ا").replace("إ","ا").replace("آ","ا");}
    private void runAiLesson(final QuranClient.Ayah x,final boolean deep,final LinearLayout output){
        if(!GeminiClient.configured(this)){Toast.makeText(this,"İlerleme > Ayarlar’dan Gemini anahtarını gir.",Toast.LENGTH_LONG).show();return;}
        output.removeAllViews();output.addView(tv("FEHM öğretmeni hazırlanıyor…",14,MUTED,Typeface.NORMAL),full());final int stage=learningStage();final String foundation=trustedFoundation(x);
        new Thread(new Runnable(){public void run(){try{
            String prompt=deep?deepPrompt(x,stage,foundation):beginnerPrompt(x,stage,foundation);final String ans=GeminiClient.generate(MainActivity.this,prompt,false);
            runOnUiThread(new Runnable(){public void run(){renderAiAnswer(output,ans,deep);FehmStore s=FehmStore.get(MainActivity.this);s.put("analysisScore",""+Math.min(100,s.getInt("analysisScore",0)+2));s.session("analysis",1,1,0);DriveBackup.maybeAutoBackup(MainActivity.this);}});
        }catch(final Exception e){runOnUiThread(new Runnable(){public void run(){output.removeAllViews();output.addView(tv(e.getMessage(),14,BAD,Typeface.NORMAL),full());}});}}}).start();
    }
    private String beginnerPrompt(QuranClient.Ayah x,int stage,String foundation){
        return "Sen FEHM adlı Kur’an Arapçası öğretmenisin. Öğrenci Türkçe konuşuyor ve seviye="+stageName(stage)+". Amaç: duyduğunu anlamaya başlayabilmesi. Bir derste az bilgi ver. Kök/morfoloji tahmin etme; yalnız YEREL DOĞRULANMIŞ VERİ içinde açıkça verilen kökü kullan. Kök bilgisi verilmemişse 'bu derste kök doğrulanmadı' de. Dil analizi ile yorum/tefsiri ayır. Markdown kullanma. SADECE geçerli JSON döndür.\n\nAYET: "+QuranMeta.label(x.surah,x.ayah)+"\nARAPÇA: "+x.arabic+"\nLATİN: "+x.latin+"\nDİYANET: "+x.diyanet+"\nYEREL DOĞRULANMIŞ VERİ:\n"+foundation+"\nJSON ŞEMASI: {\"intro\":\"1-2 cümle\",\"words\":[{\"arabic\":\"\",\"latin\":\"\",\"meaning\":\"\",\"note\":\"çok kısa\"}],\"rootTitle\":\"Bugünün kökü\",\"rootText\":\"yalnız doğrulanmışsa tek kök veya kök yok mesajı\",\"grammarTitle\":\"Bugünün tek grameri\",\"grammarText\":\"yalnız ayeti anlamaya yarayan tek küçük kural\",\"catchText\":\"Bu ayeti duyunca yakalaman gereken 1-2 parça\",\"question\":\"tek mini hatırlama sorusu\",\"answer\":\"çok kısa cevap\"}. words en fazla 6 öğe olsun.";
    }
    private String deepPrompt(QuranClient.Ayah x,int stage,String foundation){
        return "Sen FEHM adlı Kur’an Arapçası öğretmenisin. Öğrenci Türkçe konuşuyor. Seviye="+stageName(stage)+". Bu istek DERİNLEŞTİR modudur. Kök/morfoloji tahmin etme; yalnız YEREL DOĞRULANMIŞ VERİ içindeki bilgileri kesin dil verisi gibi kullan. Verilmeyen yerde açıkça 'doğrulanmış yerel veri yok' yaz. Etimolojik ihtilaf varsa tek görüşü kesinleştirme. Dil analizi, meal tercihi ve yorum/tefsiri ayrı tut. Markdown kullanma. SADECE geçerli JSON döndür.\nAYET: "+QuranMeta.label(x.surah,x.ayah)+"\nARAPÇA: "+x.arabic+"\nLATİN: "+x.latin+"\nDİYANET: "+x.diyanet+"\nELMALILI: "+x.elmalili+"\nVAKIF: "+x.vakif+"\nYEREL DOĞRULANMIŞ VERİ:\n"+foundation+"\nJSON ŞEMASI: {\"intro\":\"kısa giriş\",\"sections\":[{\"title\":\"Kelime ve ses\",\"body\":\"...\"},{\"title\":\"Kök ve anlam ailesi\",\"body\":\"...\"},{\"title\":\"Gramer örüntüsü\",\"body\":\"...\"},{\"title\":\"Meal farkları ve bağlam\",\"body\":\"...\"},{\"title\":\"Kendi cümlenle anlam\",\"body\":\"...\"}],\"boundary\":\"Kesin dil verisi ile yorumun sınırını bir cümlede belirt\"}.";
    }
    private void renderAiAnswer(LinearLayout output,String ans,boolean deep){
        output.removeAllViews();try{JSONObject o=new JSONObject(GeminiClient.cleanJson(ans));String intro=TextClean.plain(o.optString("intro"));if(!intro.isEmpty())output.addView(tv(intro,14,TEXT,Typeface.NORMAL),full());
            if(!deep){JSONArray words=o.optJSONArray("words");if(words!=null&&words.length()>0){addAiHeading(output,"KELİME KELİME YAKALA");for(int i=0;i<words.length();i++){JSONObject w=words.optJSONObject(i);if(w==null)continue;LinearLayout row=new LinearLayout(this);row.setOrientation(LinearLayout.VERTICAL);TextView ar=tv(TextClean.plain(w.optString("arabic")),22,TEXT,Typeface.BOLD);ar.setGravity(Gravity.RIGHT);row.addView(ar,full());row.addView(tv(TextClean.plain(w.optString("latin"))+" · "+TextClean.plain(w.optString("meaning")),14,GOLD,Typeface.BOLD),space(2));String note=TextClean.plain(w.optString("note"));if(!note.isEmpty())row.addView(tv(note,12,MUTED,Typeface.NORMAL),space(2));output.addView(row,space(8));}}
                addAiSection(output,o.optString("rootTitle","BUGÜNÜN KÖKÜ"),o.optString("rootText"));addAiSection(output,o.optString("grammarTitle","BUGÜNÜN TEK GRAMERİ"),o.optString("grammarText"));addAiSection(output,"ŞİMDİ DUYUNCA YAKALA",o.optString("catchText"));addAiQuiz(output,o.optString("question"),o.optString("answer"));
            }else{JSONArray sec=o.optJSONArray("sections");if(sec!=null)for(int i=0;i<sec.length();i++){JSONObject s=sec.optJSONObject(i);if(s!=null)addAiSection(output,s.optString("title","BÖLÜM"),s.optString("body"));}addAiSection(output,"SINIR",o.optString("boundary"));}
        }catch(Exception e){output.addView(tv(TextClean.plain(ans),14,TEXT,Typeface.NORMAL),full());}
    }
    private void addAiHeading(LinearLayout p,String title){p.addView(tv(title,11,GOLD,Typeface.BOLD),space(12));}
    private void addAiSection(LinearLayout p,String title,String body){body=TextClean.plain(body);if(body.isEmpty())return;p.addView(tv(TextClean.plain(title).toUpperCase(new Locale("tr","TR")),11,GOLD,Typeface.BOLD),space(12));p.addView(tv(body,14,TEXT,Typeface.NORMAL),space(4));}
    private void addAiQuiz(LinearLayout p,String question,String answer){question=TextClean.plain(question);answer=TextClean.plain(answer);if(question.isEmpty())return;p.addView(tv("MİNİ HATIRLAMA",11,GOLD,Typeface.BOLD),space(12));p.addView(tv(question,14,TEXT,Typeface.NORMAL),space(4));if(!answer.isEmpty()){final TextView a=tv("",13,GOLD,Typeface.BOLD);final Button b=outlineButton("CEVABI GÖSTER");final String finalAnswer=answer;b.setOnClickListener(new View.OnClickListener(){public void onClick(View v){a.setText(finalAnswer);v.setVisibility(View.GONE);}});p.addView(b,height(40,7));p.addView(a,space(4));}}

    private void showProgress(){
        shell("Kendi hızında ilerle","FEHM · İlerleme",4);FehmStore s=FehmStore.get(this);CourseData d=CourseData.get(this);LinearLayout c=card();c.addView(tv("BECERİ HARİTASI",11,GOLD,Typeface.BOLD),full());int letters=Math.min(100,(int)(100.0*s.getInt("letterIndex",0)/Math.max(1,d.letters.size())));int words=(int)(100.0*s.learnedCount("word")/Math.max(1,d.words.size()));c.addView(progressLine("Okuma / Elif-Bâ",letters),space(9));c.addView(progressLine("Kelime",words),space(7));c.addView(progressLine("Dinleme",Math.min(100,s.getInt("listenScore",0))),space(7));c.addView(progressLine("Gramer",Math.min(100,(int)(100.0*s.getInt("grammarIndex",0)/Math.max(1,d.grammar.size())))),space(7));c.addView(progressLine("Ayet Çözümleme",Math.min(100,s.getInt("analysisScore",0))),space(7));root.addView(c,cardLp());
        LinearLayout philosophy=card();philosophy.addView(tv("SEVİYE MANTIĞI",11,GOLD,Typeface.BOLD),full());philosophy.addView(tv("0 · İlk kez görüyorum\n1 · Tanıyorum\n2 · Duyunca/seçenek içinde buluyorum\n3 · Anlamını hatırlıyorum\n4 · Ayette tanıyorum\n5 · Başka bağlamda ayırt ediyorum\n6 · Güçlü",13,TEXT,Typeface.NORMAL),space(7));root.addView(philosophy,cardLp());Button settings=button("AYARLAR · AI · DRIVE YEDEĞİ");settings.setOnClickListener(new View.OnClickListener(){public void onClick(View v){showSettings();}});root.addView(settings,height(50,12));
    }
    private LinearLayout progressLine(String name,int pct){LinearLayout x=new LinearLayout(this);x.setOrientation(LinearLayout.VERTICAL);x.addView(tv(name+" · %"+Math.max(0,Math.min(100,pct)),13,TEXT,Typeface.BOLD),full());ProgressBar b=new ProgressBar(this,null,android.R.attr.progressBarStyleHorizontal);b.setMax(100);b.setProgress(Math.max(0,Math.min(100,pct)));x.addView(b,height(12,5));return x;}
    private void showSettings(){
        shell("Cihazda çalışır · Drive yalnız yedek","FEHM · Ayarlar",4);LinearLayout ai=card();ai.addView(tv("GEMINI ÖĞRETMEN",11,GOLD,Typeface.BOLD),full());final EditText key=input("Gemini API anahtarı",GeminiClient.key(this));key.setInputType(android.text.InputType.TYPE_CLASS_TEXT|android.text.InputType.TYPE_TEXT_VARIATION_PASSWORD);final EditText model=input("Model",GeminiClient.model(this));ai.addView(key,height(48,10));ai.addView(model,height(48,8));Button save=button("AI AYARLARINI KAYDET");save.setOnClickListener(new View.OnClickListener(){public void onClick(View v){GeminiClient.save(MainActivity.this,key.getText().toString(),model.getText().toString());Toast.makeText(MainActivity.this,"Kaydedildi",Toast.LENGTH_SHORT).show();}});ai.addView(save,height(46,10));root.addView(ai,cardLp());
        LinearLayout backup=card();backup.addView(tv("DRIVE YEDEĞİ / GERİ YÜKLEME",11,GOLD,Typeface.BOLD),full());backup.addView(tv("FEHM günlük kullanımda Drive’a bağımlı değildir. Öğrenme verisi cihazdadır. Drive yalnız yedek ve geri yükleme için kullanılır. API anahtarı yedeğe yazılmaz.",13,TEXT,Typeface.NORMAL),space(7));final TextView status=tv(DriveBackup.autoStatus(this),12,MUTED,Typeface.NORMAL);backup.addView(status,space(7));Button auto=outlineButton(DriveBackup.autoConfigured(this)?"OTOMATİK YEDEK DOSYASINI DEĞİŞTİR":"OTOMATİK YEDEĞİ KUR");auto.setOnClickListener(new View.OnClickListener(){public void onClick(View v){DriveBackup.chooseAuto(MainActivity.this);}});backup.addView(auto,height(44,10));if(DriveBackup.autoConfigured(this)){Button now=outlineButton("OTOMATİK YEDEĞİ ŞİMDİ GÜNCELLE");now.setOnClickListener(new View.OnClickListener(){public void onClick(View v){try{DriveBackup.backupNowAuto(MainActivity.this);Toast.makeText(MainActivity.this,"Otomatik Drive yedeği güncellendi.",Toast.LENGTH_LONG).show();showSettings();}catch(Exception e){Toast.makeText(MainActivity.this,e.getMessage(),Toast.LENGTH_LONG).show();}}});backup.addView(now,height(44,8));}
        Button ex=button("TARİHLİ YEDEK OLUŞTUR");ex.setOnClickListener(new View.OnClickListener(){public void onClick(View v){DriveBackup.chooseExport(MainActivity.this);}});backup.addView(ex,height(46,10));Button im=outlineButton("YEDEKTEN GERİ YÜKLE");im.setOnClickListener(new View.OnClickListener(){public void onClick(View v){DriveBackup.chooseImport(MainActivity.this);}});backup.addView(im,height(46,8));root.addView(backup,cardLp());
    }
    @Override protected void onActivityResult(int request,int result,Intent data){
        super.onActivityResult(request,result,data);if(result!=RESULT_OK||data==null||data.getData()==null)return;final Uri u=data.getData();
        if(request==DriveBackup.EXPORT){try{DriveBackup.exportTo(this,u);Toast.makeText(this,"FEHM yedeği kaydedildi.",Toast.LENGTH_LONG).show();}catch(Exception e){Toast.makeText(this,e.getMessage(),Toast.LENGTH_LONG).show();}}
        else if(request==DriveBackup.AUTO_SETUP){try{DriveBackup.rememberAuto(this,u);DriveBackup.backupNowAuto(this);Toast.makeText(this,"Otomatik Drive yedeği kuruldu.",Toast.LENGTH_LONG).show();showSettings();}catch(Exception e){Toast.makeText(this,e.getMessage(),Toast.LENGTH_LONG).show();}}
        else if(request==DriveBackup.IMPORT){new AlertDialog.Builder(this).setTitle("Yedeği geri yükle").setMessage("Mevcut öğrenme ilerlemesi seçilen yedekle değiştirilecek. Devam edilsin mi?").setNegativeButton("Vazgeç",null).setPositiveButton("Geri Yükle",new DialogInterface.OnClickListener(){public void onClick(DialogInterface d,int w){try{DriveBackup.importFrom(MainActivity.this,u);Toast.makeText(MainActivity.this,"Yedek geri yüklendi.",Toast.LENGTH_LONG).show();showProgress();}catch(Exception e){Toast.makeText(MainActivity.this,e.getMessage(),Toast.LENGTH_LONG).show();}}}).show();}
    }

    private TextView tv(String s,float size,int color,int style){TextView t=new TextView(this);t.setText(s);t.setTextSize(size);t.setTextColor(color);t.setTypeface(null,style);t.setLineSpacing(dp(2),1.08f);return t;}
    private TextView center(TextView t){t.setGravity(Gravity.CENTER);return t;}
    private LinearLayout card(){LinearLayout c=new LinearLayout(this);c.setOrientation(LinearLayout.VERTICAL);c.setPadding(dp(17),dp(16),dp(17),dp(16));c.setBackground(round(PANEL,Color.argb(80,220,184,91),1,18));return c;}
    private LinearLayout.LayoutParams full(){return new LinearLayout.LayoutParams(-1,-2);}private LinearLayout.LayoutParams cardLp(){LinearLayout.LayoutParams p=full();p.topMargin=dp(10);return p;}private LinearLayout.LayoutParams space(int top){LinearLayout.LayoutParams p=full();p.topMargin=dp(top);return p;}private LinearLayout.LayoutParams height(int h,int top){LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,dp(h));p.topMargin=dp(top);return p;}
    private Button button(String s){Button b=new Button(this);b.setText(s);b.setTextSize(11);b.setTextColor(BG);b.setTypeface(null,Typeface.BOLD);b.setBackground(round(GOLD,GOLD,1,12));return b;}
    private Button outlineButton(String s){Button b=new Button(this);b.setText(s);b.setTextSize(10);b.setTextColor(GOLD);b.setTypeface(null,Typeface.BOLD);b.setBackground(round(PANEL2,GOLD,1,11));return b;}
    private Button smallButton(String s,int fill){Button b=new Button(this);b.setText(s);b.setTextSize(10);b.setTextColor(TEXT);b.setTypeface(null,Typeface.BOLD);b.setBackground(round(fill,fill,1,11));return b;}
    private EditText input(String hint,String val){EditText e=new EditText(this);e.setHint(hint);e.setText(val);e.setSingleLine(true);e.setTextColor(TEXT);e.setHintTextColor(MUTED);e.setTextSize(16);e.setPadding(dp(12),0,dp(12),0);e.setBackground(round(PANEL2,Color.argb(80,220,184,91),1,12));return e;}
    private GradientDrawable round(int fill,int stroke,int sw,int radius){GradientDrawable g=new GradientDrawable();g.setColor(fill);g.setCornerRadius(dp(radius));if(sw>0)g.setStroke(dp(sw),stroke);return g;}
    private int parse(String s,int d){try{return Integer.parseInt(s.trim());}catch(Exception e){return d;}}
}
