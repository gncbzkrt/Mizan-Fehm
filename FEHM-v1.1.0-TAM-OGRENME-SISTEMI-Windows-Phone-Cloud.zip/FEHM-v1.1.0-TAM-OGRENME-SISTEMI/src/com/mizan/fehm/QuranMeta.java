package com.mizan.fehm;

import java.util.Calendar;

final class QuranMeta {
    private static final String[] NAMES = {
        "",
        "Fâtiha","Bakara","Âl-i İmrân","Nisâ","Mâide","En'âm","A'râf","Enfâl","Tevbe","Yûnus",
        "Hûd","Yûsuf","Ra'd","İbrâhîm","Hicr","Nahl","İsrâ","Kehf","Meryem","Tâhâ",
        "Enbiyâ","Hac","Mü'minûn","Nûr","Furkân","Şuarâ","Neml","Kasas","Ankebût","Rûm",
        "Lokmân","Secde","Ahzâb","Sebe'","Fâtır","Yâsîn","Sâffât","Sâd","Zümer","Mü'min (Gâfir)",
        "Fussilet","Şûrâ","Zuhruf","Duhân","Câsiye","Ahkâf","Muhammed","Fetih","Hucurât","Kâf",
        "Zâriyât","Tûr","Necm","Kamer","Rahmân","Vâkıa","Hadîd","Mücâdele","Haşr","Mümtehine",
        "Saff","Cum'a","Münâfikûn","Tegâbün","Talâk","Tahrîm","Mülk","Kalem","Hâkka","Meâric",
        "Nûh","Cin","Müzzemmil","Müddessir","Kıyâmet","İnsan","Mürselât","Nebe'","Nâziât","Abese",
        "Tekvîr","İnfitâr","Mutaffifîn","İnşikâk","Bürûc","Târık","A'lâ","Gâşiye","Fecr","Beled",
        "Şems","Leyl","Duhâ","İnşirâh","Tîn","Alak","Kadr","Beyyine","Zilzâl","Âdiyât",
        "Kâria","Tekâsür","Asr","Hümeze","Fîl","Kureyş","Mâûn","Kevser","Kâfirûn","Nasr",
        "Tebbet (Mesed)","İhlâs","Felak","Nâs"
    };

    private static final int[][] BEGINNER_VERSES = {
        {1,1},{1,2},{1,3},{1,4},{1,5},{1,6},{1,7},
        {112,1},{112,2},{112,3},{112,4},
        {113,1},{113,2},{114,1},{114,2},
        {103,1},{103,2},{103,3},{94,5},{94,6},
        {2,255},{2,286},{65,2},{65,3},{39,53}
    };

    static String name(int surah){
        if(surah<1||surah>=NAMES.length)return "Sure "+surah;
        return NAMES[surah];
    }

    static String label(int surah,int ayah){return name(surah)+" "+surah+"/"+ayah;}

    static String[] labels(){
        String[] out=new String[114];
        for(int i=1;i<=114;i++)out[i-1]=i+" · "+name(i);
        return out;
    }

    static int[] suggestion(){
        int day=Calendar.getInstance().get(Calendar.DAY_OF_YEAR);
        int[] p=BEGINNER_VERSES[Math.abs(day)%BEGINNER_VERSES.length];
        return new int[]{p[0],p[1]};
    }

    private QuranMeta(){}
}
