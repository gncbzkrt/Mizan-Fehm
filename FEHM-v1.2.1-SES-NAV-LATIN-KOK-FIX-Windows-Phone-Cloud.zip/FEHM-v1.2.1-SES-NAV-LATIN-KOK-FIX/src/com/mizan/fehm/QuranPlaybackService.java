package com.mizan.fehm;

import android.app.*;
import android.content.*;
import android.media.*;
import android.os.*;

public class QuranPlaybackService extends Service {
    static final String ACTION_START="com.mizan.fehm.PLAY_START";
    static final String ACTION_STOP="com.mizan.fehm.PLAY_STOP";
    static final String ACTION_STATE="com.mizan.fehm.PLAY_STATE";
    static final String EXTRA_SURAH="surah", EXTRA_AYAH="ayah", EXTRA_RECITER="reciter", EXTRA_CONT="continuous";
    private MediaPlayer p; private AudioManager audioManager; private int surah=1,ayah=1; private String reciter=Reciters.MAHER_64; private boolean continuous=true; private static final int NID=7012; private int playToken=0;

    @Override public void onCreate(){super.onCreate();createChannel();audioManager=(AudioManager)getSystemService(AUDIO_SERVICE);}
    @Override public int onStartCommand(Intent i,int flags,int startId){
        if(i==null){android.content.SharedPreferences sp=getSharedPreferences("fehm_playback",MODE_PRIVATE);if(!sp.getBoolean("active",false)){stopSelf();return START_NOT_STICKY;}surah=sp.getInt("surah",1);ayah=sp.getInt("ayah",1);reciter=sp.getString("reciter",Reciters.MAHER_64);continuous=sp.getBoolean("continuous",true);playCurrent();return START_STICKY;}
        String a=i.getAction();if(ACTION_STOP.equals(a)){broadcast("stopped");stopAll();return START_NOT_STICKY;}surah=i.getIntExtra(EXTRA_SURAH,1);ayah=i.getIntExtra(EXTRA_AYAH,1);reciter=i.getStringExtra(EXTRA_RECITER);if(reciter==null)reciter=Reciters.MAHER_64;continuous=i.getBooleanExtra(EXTRA_CONT,true);playCurrent();return START_STICKY;
    }

    private void playCurrent(){
        release();requestAudioFocus();ayah=QuranMeta.clampAyah(surah,ayah);final int token=++playToken;final int ss=surah,aa=ayah;final String rr=reciter;
        getSharedPreferences("fehm_playback",MODE_PRIVATE).edit().putBoolean("active",true).putInt("surah",surah).putInt("ayah",ayah).putString("reciter",reciter).putBoolean("continuous",continuous).apply();
        startForeground(NID,notification());broadcast("loading");
        new Thread(new Runnable(){public void run(){
            String src;
            try{QuranAudioCache.download(QuranPlaybackService.this,rr,ss,aa);src=QuranAudioCache.file(QuranPlaybackService.this,rr,ss,aa).getAbsolutePath();}
            catch(Exception e){src=Reciters.url(rr,ss,aa);}
            final String chosen=src;new Handler(getMainLooper()).post(new Runnable(){public void run(){if(token!=playToken)return;startMedia(chosen,false,token);}});
        }}).start();
        prefetchAhead();
    }

    private void startMedia(String src,final boolean fallbackUsed,final int token){
        try{
            release();p=new MediaPlayer();p.setAudioStreamType(AudioManager.STREAM_MUSIC);p.setWakeMode(this,PowerManager.PARTIAL_WAKE_LOCK);p.setDataSource(src);
            p.setOnPreparedListener(new MediaPlayer.OnPreparedListener(){public void onPrepared(MediaPlayer m){if(token!=playToken)return;m.start();broadcast("playing");}});
            p.setOnCompletionListener(new MediaPlayer.OnCompletionListener(){public void onCompletion(MediaPlayer m){if(token!=playToken)return;if(continuous&&ayah<QuranMeta.ayahCount(surah)){ayah++;playCurrent();}else{broadcast("complete");stopAll();}}});
            p.setOnErrorListener(new MediaPlayer.OnErrorListener(){public boolean onError(MediaPlayer m,int what,int extra){if(token!=playToken)return true;if(!fallbackUsed){release();startMedia(Reciters.fallbackUrl(reciter,surah,ayah),true,token);}else{broadcast("error");stopAll();}return true;}});
            p.prepareAsync();
        }catch(Exception e){if(!fallbackUsed)startMedia(Reciters.fallbackUrl(reciter,surah,ayah),true,token);else{broadcast("error");stopAll();}}
    }
    private void requestAudioFocus(){try{if(audioManager!=null)audioManager.requestAudioFocus(null,AudioManager.STREAM_MUSIC,AudioManager.AUDIOFOCUS_GAIN);}catch(Exception ignored){}}
    private void prefetchAhead(){final int ss=surah,aa=ayah;final String rr=reciter;new Thread(new Runnable(){public void run(){for(int n=aa+1;n<=Math.min(QuranMeta.ayahCount(ss),aa+2);n++){try{QuranAudioCache.download(QuranPlaybackService.this,rr,ss,n);}catch(Exception ignored){break;}}}}).start();}
    private Notification notification(){Intent open=new Intent(this,MainActivity.class);PendingIntent pi=PendingIntent.getActivity(this,0,open,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);Intent stop=new Intent(this,QuranPlaybackService.class);stop.setAction(ACTION_STOP);PendingIntent sp=PendingIntent.getService(this,1,stop,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);Notification.Builder b=Build.VERSION.SDK_INT>=26?new Notification.Builder(this,"fehm_quran_audio"):new Notification.Builder(this);b.setSmallIcon(R.mipmap.ic_launcher).setContentTitle("FEHM · "+QuranMeta.label(surah,ayah)).setContentText(Reciters.name(reciter)+" · ekran kapalıyken devam eder").setContentIntent(pi).setOngoing(true).addAction(android.R.drawable.ic_media_pause,"Durdur",sp);return b.build();}
    private void broadcast(String state){Intent b=new Intent(ACTION_STATE);b.setPackage(getPackageName());b.putExtra("state",state);b.putExtra("surah",surah);b.putExtra("ayah",ayah);b.putExtra("reciter",reciter);sendBroadcast(b);}
    private void createChannel(){if(Build.VERSION.SDK_INT>=26){NotificationManager n=(NotificationManager)getSystemService(NOTIFICATION_SERVICE);NotificationChannel c=new NotificationChannel("fehm_quran_audio","FEHM Kur’an Dinleme",NotificationManager.IMPORTANCE_LOW);c.setDescription("Kur’an dinleme ve ekran kapalı oynatma");n.createNotificationChannel(c);}}
    private void stopAll(){playToken++;release();getSharedPreferences("fehm_playback",MODE_PRIVATE).edit().putBoolean("active",false).apply();try{if(audioManager!=null)audioManager.abandonAudioFocus(null);}catch(Exception ignored){}try{stopForeground(true);}catch(Exception ignored){}stopSelf();}
    private void release(){if(p!=null){try{p.stop();}catch(Exception ignored){}try{p.reset();}catch(Exception ignored){}try{p.release();}catch(Exception ignored){}p=null;}}
    @Override public void onDestroy(){release();super.onDestroy();}
    @Override public android.os.IBinder onBind(Intent i){return null;}
}
