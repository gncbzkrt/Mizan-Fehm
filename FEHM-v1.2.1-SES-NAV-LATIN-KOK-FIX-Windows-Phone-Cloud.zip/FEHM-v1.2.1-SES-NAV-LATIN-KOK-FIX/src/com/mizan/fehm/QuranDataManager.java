package com.mizan.fehm;

import android.content.*;
import android.database.sqlite.SQLiteDatabase;
import java.io.*;
import java.net.*;
import java.util.*;

final class QuranDataManager {
    interface Progress{void onProgress(int done,int total,String text);}
    static boolean quranReady(Context c){return QuranLocalStore.get(c).verseCount()>=6236;}
    static boolean morphReady(Context c){return QuranLocalStore.get(c).morphCount()>=70000;}
    static String status(Context c){QuranLocalStore d=QuranLocalStore.get(c);return "Kur’an metni: "+d.verseCount()+" / 6236 ayet\nDil/kök indeksi: "+d.morphCount()+" kök-morfoloji kaydı";}

    static void downloadFullQuran(Context c,Progress p)throws Exception{
        QuranLocalStore db=QuranLocalStore.get(c);
        // En hızlı yol: beş tam edisyonu birkaç büyük istekte al. Servis bunu desteklemezse sure bazlı, kaldığı yerden devam eden yola düş.
        try{
            if(p!=null)p.onProgress(0,5,"Tam Kur’an yerel paketi alınıyor");
            ArrayList<QuranClient.Ayah> all=QuranClient.fetchFullQuranMulti();db.putVerses(all);
            if(p!=null)p.onProgress(5,5,"6.236 ayet yerel veritabanına alındı");
            if(db.verseCount()>=6236){db.putMeta("quran_pack","complete");return;}
        }catch(Exception fastFailure){
            if(p!=null)p.onProgress(0,114,"Hızlı paket yolu kullanılamadı; sure bazlı devam ediliyor");
        }
        int completed=0;
        for(int s=1;s<=114;s++){
            if(db.verseCountForSurah(s)>=QuranMeta.ayahCount(s)){completed++;if(p!=null)p.onProgress(completed,114,QuranMeta.name(s)+" · hazır");continue;}
            ArrayList<QuranClient.Ayah> list=QuranClient.fetchSurahMulti(s);db.putVerses(list);completed++;db.putMeta("quran_last_surah",""+s);if(p!=null)p.onProgress(completed,114,QuranMeta.name(s));
        }
        if(db.verseCount()>=6236)db.putMeta("quran_pack","complete");
    }

    static void downloadMorphology(Context c,Progress p)throws Exception{
        String[] urls={
            "https://raw.githubusercontent.com/taziksh/quran-frequencies/main/data/quranic-corpus-morphology-0.4.txt",
            "https://github.com/taziksh/quran-frequencies/raw/refs/heads/main/data/quranic-corpus-morphology-0.4.txt"
        };
        File f=new File(c.getCacheDir(),"quranic-corpus-morphology-0.4.txt");Exception last=null;for(String u:urls){try{download(u,f,p);last=null;break;}catch(Exception e){last=e;}}if(last!=null)throw last;
        QuranLocalStore db=QuranLocalStore.get(c);SQLiteDatabase sql=db.writable();sql.beginTransaction();int stems=0,lines=0;try{sql.delete("morph",null,null);BufferedReader r=new BufferedReader(new InputStreamReader(new FileInputStream(f),"UTF-8"));String line;while((line=r.readLine())!=null){lines++;if(line.length()==0||line.charAt(0)=='#'||!line.startsWith("("))continue;String[] a=line.split("\\t");if(a.length<4)continue;String features=a[3];if(features.indexOf("STEM")<0)continue;int[] loc=parseLoc(a[0]);if(loc==null)continue;String lemma=feature(features,"LEM:");String root=feature(features,"ROOT:");db.putMorph(sql,loc[0],loc[1],loc[2],loc[3],a[1],lemma,root,a[2],features);stems++;if(p!=null&&stems%3000==0)p.onProgress(stems,78000,"Dil indeksi hazırlanıyor");}r.close();sql.setTransactionSuccessful();}finally{sql.endTransaction();}db.putMeta("morph_pack","complete");db.putMeta("morph_count",""+stems);if(p!=null)p.onProgress(stems,stems,"Dil indeksi hazır");try{f.delete();}catch(Exception ignored){}
    }

    static void downloadEverything(Context c,Progress p)throws Exception{if(!quranReady(c))downloadFullQuran(c,p);if(!morphReady(c))downloadMorphology(c,p);}

    private static void download(String u,File f,Progress p)throws Exception{HttpURLConnection h=(HttpURLConnection)new URL(u).openConnection();h.setConnectTimeout(15000);h.setReadTimeout(60000);h.setRequestProperty("User-Agent","FEHM/1.2.1");int code=h.getResponseCode();if(code<200||code>=300){h.disconnect();throw new IOException("Dil paketi HTTP "+code);}int len=h.getContentLength();InputStream in=h.getInputStream();FileOutputStream out=new FileOutputStream(f);byte[] b=new byte[32768];int n;long done=0;while((n=in.read(b))>0){out.write(b,0,n);done+=n;if(p!=null&&len>0&&done%(512*1024)<32768)p.onProgress((int)Math.min(Integer.MAX_VALUE,done),(int)Math.min(Integer.MAX_VALUE,len),"Dil paketi indiriliyor");}out.flush();out.close();in.close();h.disconnect();}
    private static int[] parseLoc(String s){try{String x=s.replace("(","").replace(")","");String[] p=x.split(":");if(p.length<4)return null;return new int[]{Integer.parseInt(p[0]),Integer.parseInt(p[1]),Integer.parseInt(p[2]),Integer.parseInt(p[3])};}catch(Exception e){return null;}}
    private static String feature(String f,String key){int i=f.indexOf(key);if(i<0)return "";i+=key.length();int e=f.indexOf('|',i);return e<0?f.substring(i):f.substring(i,e);}
    private QuranDataManager(){}
}
