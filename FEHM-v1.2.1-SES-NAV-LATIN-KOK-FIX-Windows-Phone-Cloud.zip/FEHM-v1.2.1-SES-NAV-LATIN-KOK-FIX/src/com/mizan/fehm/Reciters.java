package com.mizan.fehm;

final class Reciters {
    static final String MAHER_64="maher64";
    static final String MAHER_128="maher128";
    static final String ALAFASY_64="alafasy64";

    static String name(String id){
        if(MAHER_128.equals(id))return "Mahir el-Muaykıli · 128 kbps";
        if(ALAFASY_64.equals(id))return "Mişârî el-Afâsî · İlk FEHM sesi · 64 kbps";
        return "Mahir el-Muaykıli · 64 kbps";
    }

    static String shortName(String id){return ALAFASY_64.equals(id)?"Mişârî el-Afâsî":"Mahir el-Muaykıli";}

    static String url(String id,int surah,int ayah){
        // Mahir için saha testinde Islamic Network akışı bazı cihazlarda başarısız oldu.
        // EveryAyah ayet-bazlı arşivini birincil kaynak yapıyoruz; aynı dosya düzeni
        // çevrimdışı sure indirmesinde de kullanılıyor.
        if(MAHER_128.equals(id))return "https://everyayah.com/data/MaherAlMuaiqly128kbps/"+pad3(surah)+pad3(ayah)+".mp3";
        if(MAHER_64.equals(id))return "https://everyayah.com/data/Maher_AlMuaiqly_64kbps/"+pad3(surah)+pad3(ayah)+".mp3";
        int global=QuranMeta.globalNumber(surah,ayah);if(global<1)global=1;
        return "https://cdn.islamic.network/quran/audio/64/ar.alafasy/"+global+".mp3";
    }

    static String fallbackUrl(String id,int surah,int ayah){
        int global=QuranMeta.globalNumber(surah,ayah);if(global<1)global=1;
        if(MAHER_128.equals(id))return "https://cdn.islamic.network/quran/audio/128/ar.mahermuaiqly/"+global+".mp3";
        if(MAHER_64.equals(id))return "https://cdn.islamic.network/quran/audio/64/ar.mahermuaiqly/"+global+".mp3";
        return "https://everyayah.com/data/Alafasy_64kbps/"+pad3(surah)+pad3(ayah)+".mp3";
    }

    static String[] ids(){return new String[]{MAHER_64,MAHER_128,ALAFASY_64};}
    static String[] names(){return new String[]{name(MAHER_64),name(MAHER_128),name(ALAFASY_64)};}
    private static String pad3(int n){if(n<10)return "00"+n;if(n<100)return "0"+n;return ""+n;}
    private Reciters(){}
}
