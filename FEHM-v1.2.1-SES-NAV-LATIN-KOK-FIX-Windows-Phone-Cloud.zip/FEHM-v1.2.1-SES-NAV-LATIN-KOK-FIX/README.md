# FEHM v1.2.1 — Ses · Navigasyon · Latin · Kök Fix

v1.2.0'ın yerel Kur’an + 77 bin morfoloji mimarisi korunmuştur. Bu sürüm saha testinde bulunan ses, gezinme ve başlangıç-seviyesi okunabilirlik sorunlarını düzeltir.

## Ana değişiklikler

- Mahir el-Muaykıli 64/128 kbps için EveryAyah ayet arşivi birincil, Islamic Network / AlQuran Cloud CDN yedek ses kaynağıdır.
- Mişârî el-Afâsî 64 kbps, “İlk FEHM sesi” etiketiyle okuyucu listesinde tutulur.
- Tefekkür, Dinleme dersi ve Ayet Laboratuvarı seslerinde ekran kapalı oynatma + sonraki ayet önbelleği.
- Her FEHM sayfasında aktif dinleme varken kalıcı mini oynatıcı: Dinlemeye Dön / Durdur.
- Android geri tuşu önceki FEHM ekranına döner.
- Sözlük, kelime-kök haritası ve gramer örneklerinde Arapça biçimin yanında/altında Latin okunuş gösterilir.
- Kök satırı: `Arapça · Latin · Türkçe`.
- Lemma satırı: `Arapça · Latin`.
- Türkçe anlamdan bazı köklere doğrudan geçiş ve başlangıç sözlüğü üzerinden kök eşleme.
- AI açıklamalarında Arapça tek başına bırakılmaz; Latin karşılığı istenir.
- Ayarlar'da gerçek yerel veri/ses depolama kullanımı.

## Telefonda GitHub Actions ile APK

Repoda eski `FEHM*.zip` dosyasını kaldırıp bu sürüm ZIP'ini yükleyin. Var olan `FEHM APK Oluştur` workflow'unu çalıştırın. Artifact içindeki APK mevcut FEHM'in üzerine güncelleme olarak kurulabilir.

Çıktı adı:
`FEHM-v1.2.1-SES-NAV-LATIN-KOK-FIX.apk`
