$ErrorActionPreference = 'Stop'
$ProjectDir = Split-Path -Parent $MyInvocation.MyCommand.Path
$SdkRoot = if ($env:FEHM_ANDROID_SDK) { $env:FEHM_ANDROID_SDK } elseif ($env:ANDROID_SDK_ROOT) { $env:ANDROID_SDK_ROOT } elseif ($env:ANDROID_HOME) { $env:ANDROID_HOME } else { Join-Path $env:LOCALAPPDATA 'Android\Sdk' }
$JdkRoot = if ($env:FEHM_JDK) { $env:FEHM_JDK } else { 'C:\Program Files\Android\Android Studio\jbr' }
$BuildTools = Join-Path $SdkRoot 'build-tools\35.0.0'; $PlatformJar = Join-Path $SdkRoot 'platforms\android-35\android.jar'
$BuildDir=Join-Path $ProjectDir 'build'; $OutputDir=Join-Path $ProjectDir 'output'; $Keystore=Join-Path $ProjectDir 'signing\fehm-release.jks'; $StorePass='FehmKisisel2026'; $KeyAlias='fehm'
$Aapt2=Join-Path $BuildTools 'aapt2.exe'; $D8=Join-Path $BuildTools 'd8.bat'; $Zipalign=Join-Path $BuildTools 'zipalign.exe'; $Apksigner=Join-Path $BuildTools 'apksigner.bat'; $Javac=Join-Path $JdkRoot 'bin\javac.exe'; $Jar=Join-Path $JdkRoot 'bin\jar.exe'; $Keytool=Join-Path $JdkRoot 'bin\keytool.exe'; $env:JAVA_HOME=$JdkRoot; $env:PATH=(Join-Path $JdkRoot 'bin')+';'+$env:PATH
function Need($p,$n){if(-not(Test-Path $p)){throw "EKSIK: $n -> $p"}}
Need $Aapt2 'aapt2';Need $D8 'd8';Need $Zipalign 'zipalign';Need $Apksigner 'apksigner';Need $PlatformJar 'android-35';Need $Javac 'javac';Need $Jar 'jar';Need $Keytool 'keytool'
if(Test-Path $BuildDir){Remove-Item $BuildDir -Recurse -Force};New-Item -ItemType Directory -Force -Path (Join-Path $BuildDir 'gen'),(Join-Path $BuildDir 'classes'),(Join-Path $BuildDir 'dex'),$OutputDir,(Join-Path $ProjectDir 'signing')|Out-Null
& $Aapt2 compile --dir (Join-Path $ProjectDir 'res') -o (Join-Path $BuildDir 'resources.zip'); if($LASTEXITCODE-ne 0){throw 'aapt2 compile'}
& $Aapt2 link -I $PlatformJar --manifest (Join-Path $ProjectDir 'AndroidManifest.xml') --java (Join-Path $BuildDir 'gen') --min-sdk-version 23 --target-sdk-version 35 --version-code 4 --version-name 1.2.1 -A (Join-Path $ProjectDir 'assets') -o (Join-Path $BuildDir 'base.apk') (Join-Path $BuildDir 'resources.zip'); if($LASTEXITCODE-ne 0){throw 'aapt2 link'}
$files=@();$files+=Get-ChildItem (Join-Path $ProjectDir 'src') -Recurse -Filter '*.java'|% FullName;$files+=Get-ChildItem (Join-Path $BuildDir 'gen') -Recurse -Filter '*.java'|% FullName;$arg=Join-Path $BuildDir 'javac.txt';$files|%{'"'+($_.Replace('\','/'))+'"'}|Set-Content -Encoding ASCII $arg
& $Javac -encoding UTF-8 -source 8 -target 8 -bootclasspath $PlatformJar -d (Join-Path $BuildDir 'classes') "@$arg";if($LASTEXITCODE-ne 0){throw 'javac'}
$classes=Join-Path $BuildDir 'classes.jar';Push-Location (Join-Path $BuildDir 'classes');try{& $Jar cf $classes '.'}finally{Pop-Location}; & $D8 --lib $PlatformJar --min-api 23 --output (Join-Path $BuildDir 'dex') $classes;if($LASTEXITCODE-ne 0){throw 'd8'}
$with=Join-Path $BuildDir 'with-dex.apk';Copy-Item (Join-Path $BuildDir 'base.apk') $with -Force;& $Jar uf $with -C (Join-Path $BuildDir 'dex') 'classes.dex';$aligned=Join-Path $BuildDir 'aligned.apk';& $Zipalign -f -p 4 $with $aligned
if(-not(Test-Path $Keystore)){& $Keytool -genkeypair -noprompt -keystore $Keystore -storepass $StorePass -keypass $StorePass -alias $KeyAlias -keyalg RSA -keysize 2048 -validity 10000 -dname 'CN=FEHM Kisisel, OU=Kisisel, O=FEHM, C=TR'}
$apk=Join-Path $OutputDir 'FEHM-v1.2.1-SES-NAV-LATIN-KOK-FIX.apk';& $Apksigner sign --ks $Keystore --ks-key-alias $KeyAlias --ks-pass "pass:$StorePass" --key-pass "pass:$StorePass" --out $apk $aligned;& $Apksigner verify --verbose --print-certs $apk
Write-Host '';Write-Host 'FEHM APK HAZIR:' -ForegroundColor Green;Write-Host $apk -ForegroundColor White;Start-Process explorer.exe "/select,`"$apk`""
