# FEHM v1.2.0 — Dinle · Tefekkür · Sözlük · Yerel Kur’an

FEHM, sıfır bilgiden başlayan kullanıcı için Kur’an Arapçasını **duyma, okuma, kelime/kök, gramer ve ayet çözümleme** üzerinden öğreten kişisel Android uygulamasıdır.

## v1.2.0 ana yenilikleri

- **Sadece Kur’an Dinle · Tefekkür**: ders/test olmadan sureyi kesintisiz dinleme.
- Dinlerken ekranda **Arapça + Latin harfli okunuş + Diyanet meali** birlikte gösterilir.
- **Mahir el-Muaykıli** 64 kbps ve 128 kbps ses seçenekleri; Mişârî el-Afâsî alternatif ses.
- **Ekran kapalı oynatma**: foreground media service + wake lock ile ses devam eder.
- İstenilen sureyi **çevrimdışı ses paketi** olarak telefona indirme.
- Dinleme sırasında sıradaki ayetler arka planda önbelleğe alınarak geçiş gecikmesi azaltılır.
- **Kur’an Sözlüğü**: Latin, Türkçe, Arapça, lemma veya kökle arama.
- Sadece kök yazarak aynı kökten gelen biçimleri ve Kur’an’daki kullanım yerlerini bulma.
- Sözlük sonucunda: kök, lemma, temel gramer türü, ayet referansı ve Diyanet meal bağlamı.
- İstenirse FEHM AI, doğrulanmış kök/lemma verisini bozmadan kısa Türkçe **anlam alanı** açıklaması üretir ve sonucu cihazda önbelleğe alır.
- Ayet Laboratuvarında **AYETİN KELİME · KÖK HARİTASI**: ayetteki kelimeden doğrudan kök aramasına geçiş.
- **Hızlı Yerel Kur’an Paketi**: 6.236 ayet; Arapça, Latin okunuş ve Türkçe mealler cihazdaki SQLite veritabanına alınır. Kök/morfoloji indeksi de yerel SQLite’a kurulur.
- Yerel veri paketi yarıda kalırsa mevcut ayetler korunur; tekrar denendiğinde hazır sureler yeniden indirilmez.
- Ses arşivinin tamamı zorunlu indirilmez. Depolamayı korumak için ses **sure bazında** çevrimdışı alınır.
- Dinleme dersi artık aşamalı: yalnız dinle → Latin aç → duyulan parçaları gör → meal → tekrar dinle.
- “Bana Şimdi Öğret” başlangıç seviyesinde daha kısa: en fazla 3 parça + tek küçük gramer + tek mini soru.
- “Derinleştir” ayrı kalır: kök, gramer, bağlam ve meal farkları burada açılır.
- Drive öğrenme yedeği korunur; yeniden indirilebilir Kur’an/ses cache’i Drive yedeğine dahil edilmez.

## Yerel veri kaynakları / yaklaşım

- Kur’an metni, Latin okunuş ve seçili Türkçe mealler uygulama tarafından ilk kurulum/istek sırasında çevrimdışı SQLite önbelleğine alınır.
- Kök, lemma ve morfoloji için **Quranic Arabic Corpus v0.4** veri biçimi kullanılır. QAC morfoloji verisi GNU GPL kapsamında dağıtılır; kaynak atfı korunmalıdır.
- Ses dosyaları APK içine gömülmez. Kullanıcının seçtiği okuyucudan internet üzerinden oynatılır veya seçilen sure cihazda çevrimdışı cache’e indirilir.

## Kurulum — telefondan GitHub Actions

Repo kökünde yalnız yeni FEHM ZIP dosyasını bırakın. Mevcut `.github/workflows/build-apk.yml` dosyanız ZIP’i açıp `build.sh` dosyasını otomatik buluyorsa workflow’u değiştirmeniz gerekmez.

1. Eski FEHM ZIP’ini repodan silin.
2. Bu sürümün ZIP’ini yükleyin.
3. Actions → FEHM APK Oluştur → Run workflow.
4. Artifact içinden `FEHM-v1.2.0-DINLE-TEFEKKUR-SOZLUK-LOCAL.apk` dosyasını indirin.
5. Mevcut FEHM’in üzerine kurun.

Aynı paket adı ve aynı imza anahtarı korunmuştur. Öğrenme veritabanı güncellemede silinmez.

## Windows

`build.bat` çalıştırın. Çıktı:

`output/FEHM-v1.2.0-DINLE-TEFEKKUR-SOZLUK-LOCAL.apk`
