package com.mizan.fehm;
import android.content.*;
import org.json.*;
import java.io.*;
import java.net.*;
import java.util.*;

final class QuranClient {
    static final class Ayah {int surah,ayah,global;String arabic="",latin="",diyanet="",elmalili="",vakif="";boolean ok(){return !arabic.isEmpty()&&!diyanet.isEmpty();}}

    static Ayah fetch(Context c,int surah,int ayah)throws Exception{
        surah=Math.max(1,Math.min(114,surah));ayah=QuranMeta.clampAyah(surah,ayah);
        QuranLocalStore db=QuranLocalStore.get(c);Ayah cached=db.getVerse(surah,ayah);if(cached!=null&&cached.ok())return cached;
        Ayah x=fetchNetwork(surah,ayah);db.putVerse(x);return x;
    }

    static Ayah fetchNetwork(int surah,int ayah)throws Exception{
        String u="https://api.alquran.cloud/v1/ayah/"+surah+":"+ayah+"/editions/quran-uthmani,tr.transliteration,tr.diyanet,tr.yazir,tr.vakfi";
        JSONObject root=new JSONObject(readUrl(u,35000));JSONArray a=root.optJSONArray("data");if(a==null)throw new IOException("Ayet verisi gelmedi.");Ayah x=new Ayah();x.surah=surah;x.ayah=ayah;x.global=QuranMeta.globalNumber(surah,ayah);
        for(int i=0;i<a.length();i++){JSONObject o=a.optJSONObject(i);if(o==null)continue;if(x.global==0)x.global=o.optInt("number",0);JSONObject ed=o.optJSONObject("edition");String id=ed==null?"":ed.optString("identifier");String t=o.optString("text","").trim();if("quran-uthmani".equals(id))x.arabic=t;else if("tr.transliteration".equals(id))x.latin=t;else if("tr.diyanet".equals(id))x.diyanet=t;else if("tr.yazir".equals(id))x.elmalili=t;else if("tr.vakfi".equals(id))x.vakif=t;}
        if(!x.ok())throw new IOException("Ayet metni eksik geldi.");return x;
    }

    static ArrayList<Ayah> fetchFullQuranMulti()throws Exception{
        String[] ids={"quran-uthmani","tr.transliteration","tr.diyanet","tr.yazir","tr.vakfi"};
        HashMap<String,Ayah> map=new HashMap<String,Ayah>();
        for(String id:ids){
            String u="https://api.alquran.cloud/v1/quran/"+id;
            JSONObject root=new JSONObject(readUrl(u,90000));JSONObject data=root.optJSONObject("data");if(data==null)throw new IOException("Tam Kur’an paketi gelmedi: "+id);JSONArray surahs=data.optJSONArray("surahs");if(surahs==null)throw new IOException("Tam Kur’an sureleri gelmedi: "+id);
            for(int si=0;si<surahs.length();si++){JSONObject so=surahs.optJSONObject(si);if(so==null)continue;int surah=so.optInt("number",si+1);JSONArray ayahs=so.optJSONArray("ayahs");if(ayahs==null)continue;for(int ai=0;ai<ayahs.length();ai++){JSONObject o=ayahs.optJSONObject(ai);if(o==null)continue;int ayah=o.optInt("numberInSurah",ai+1);String key=surah+":"+ayah;Ayah x=map.get(key);if(x==null){x=new Ayah();x.surah=surah;x.ayah=ayah;x.global=o.optInt("number",QuranMeta.globalNumber(surah,ayah));map.put(key,x);}String t=o.optString("text","").trim();if("quran-uthmani".equals(id))x.arabic=t;else if("tr.transliteration".equals(id))x.latin=t;else if("tr.diyanet".equals(id))x.diyanet=t;else if("tr.yazir".equals(id))x.elmalili=t;else if("tr.vakfi".equals(id))x.vakif=t;}}
        }
        ArrayList<Ayah> out=new ArrayList<Ayah>(6236);for(int ss=1;ss<=114;ss++)for(int aa=1;aa<=QuranMeta.ayahCount(ss);aa++){Ayah x=map.get(ss+":"+aa);if(x!=null)out.add(x);}
        if(out.size()<6230)throw new IOException("Tam Kur’an paketi eksik: "+out.size());return out;
    }

    static ArrayList<Ayah> fetchSurahMulti(int surah)throws Exception{
        surah=Math.max(1,Math.min(114,surah));String u="https://api.alquran.cloud/v1/surah/"+surah+"/editions/quran-uthmani,tr.transliteration,tr.diyanet,tr.yazir,tr.vakfi";JSONObject root=new JSONObject(readUrl(u,45000));JSONArray editions=root.optJSONArray("data");if(editions==null)throw new IOException("Sure paketi gelmedi: "+surah);
        HashMap<Integer,Ayah> map=new HashMap<Integer,Ayah>();
        for(int e=0;e<editions.length();e++){JSONObject edObj=editions.optJSONObject(e);if(edObj==null)continue;JSONObject ed=edObj.optJSONObject("edition");String id=ed==null?"":ed.optString("identifier");JSONArray ayahs=edObj.optJSONArray("ayahs");if(ayahs==null)continue;for(int i=0;i<ayahs.length();i++){JSONObject o=ayahs.optJSONObject(i);if(o==null)continue;int n=o.optInt("numberInSurah",i+1);Ayah x=map.get(n);if(x==null){x=new Ayah();x.surah=surah;x.ayah=n;x.global=o.optInt("number",QuranMeta.globalNumber(surah,n));map.put(n,x);}String t=o.optString("text","").trim();if("quran-uthmani".equals(id))x.arabic=t;else if("tr.transliteration".equals(id))x.latin=t;else if("tr.diyanet".equals(id))x.diyanet=t;else if("tr.yazir".equals(id))x.elmalili=t;else if("tr.vakfi".equals(id))x.vakif=t;}}
        ArrayList<Ayah> out=new ArrayList<Ayah>();for(int i=1;i<=QuranMeta.ayahCount(surah);i++){Ayah x=map.get(i);if(x!=null)out.add(x);}if(out.isEmpty())throw new IOException("Sure paketi boş geldi: "+surah);return out;
    }

    static String audioUrl(Ayah a){return Reciters.url(Reciters.MAHER_64,a.surah,a.ayah);}
    static String readUrl(String u,int timeout)throws Exception{HttpURLConnection h=(HttpURLConnection)new URL(u).openConnection();h.setConnectTimeout(12000);h.setReadTimeout(timeout);h.setRequestProperty("User-Agent","FEHM/1.2");h.setRequestProperty("Accept-Encoding","gzip");InputStream in;int code=h.getResponseCode();if(code<200||code>=300){h.disconnect();throw new IOException("Kur’an servisi HTTP "+code);}in=h.getInputStream();String enc=h.getContentEncoding();if(enc!=null&&enc.toLowerCase(Locale.US).contains("gzip"))in=new java.util.zip.GZIPInputStream(in);BufferedReader r=new BufferedReader(new InputStreamReader(in,"UTF-8"));StringBuilder b=new StringBuilder();String line;while((line=r.readLine())!=null)b.append(line);r.close();h.disconnect();return b.toString();}
    private QuranClient(){}
}
