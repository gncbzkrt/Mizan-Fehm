package com.mizan.fehm;

final class TextClean {
    static String plain(String s){
        if(s==null)return "";
        String x=s.replace("```json","").replace("```","");
        x=x.replace("### ","").replace("## ","").replace("# ","");
        x=x.replace("**","").replace("__","").replace("`","");
        x=x.replaceAll("(?m)^\\s*>\\s?","");
        x=x.replaceAll("(?m)^\\s*[-*]\\s+","• ");
        x=x.replaceAll("\\n{3,}","\\n\\n");
        return x.trim();
    }
    private TextClean(){}
}
