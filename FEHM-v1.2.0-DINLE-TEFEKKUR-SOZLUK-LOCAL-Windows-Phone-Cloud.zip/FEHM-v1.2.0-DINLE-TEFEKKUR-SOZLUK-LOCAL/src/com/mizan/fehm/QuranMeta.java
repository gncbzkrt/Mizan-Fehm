package com.mizan.fehm;

import java.util.Calendar;

final class QuranMeta {
    private static final String[] NAMES = {
        "",
        "Fâtiha","Bakara","Âl-i İmrân","Nisâ","Mâide","En'âm","A'râf","Enfâl","Tevbe","Yûnus",
        "Hûd","Yûsuf","Ra'd","İbrâhîm","Hicr","Nahl","İsrâ","Kehf","Meryem","Tâhâ",
        "Enbiyâ","Hac","Mü'minûn","Nûr","Furkân","Şuarâ","Neml","Kasas","Ankebût","Rûm",
        "Lokmân","Secde","Ahzâb","Sebe'","Fâtır","Yâsîn","Sâffât","Sâd","Zümer","Mü'min (Gâfir)",
        "Fussilet","Şûrâ","Zuhruf","Duhân","Câsiye","Ahkâf","Muhammed","Fetih","Hucurât","Kâf",
        "Zâriyât","Tûr","Necm","Kamer","Rahmân","Vâkıa","Hadîd","Mücâdele","Haşr","Mümtehine",
        "Saff","Cum'a","Münâfikûn","Tegâbün","Talâk","Tahrîm","Mülk","Kalem","Hâkka","Meâric",
        "Nûh","Cin","Müzzemmil","Müddessir","Kıyâmet","İnsan","Mürselât","Nebe'","Nâziât","Abese",
        "Tekvîr","İnfitâr","Mutaffifîn","İnşikâk","Bürûc","Târık","A'lâ","Gâşiye","Fecr","Beled",
        "Şems","Leyl","Duhâ","İnşirâh","Tîn","Alak","Kadr","Beyyine","Zilzâl","Âdiyât",
        "Kâria","Tekâsür","Asr","Hümeze","Fîl","Kureyş","Mâûn","Kevser","Kâfirûn","Nasr",
        "Tebbet (Mesed)","İhlâs","Felak","Nâs"
    };

    // Standart Hafs/Kûfî ayet sayıları; toplam 6236.
    private static final int[] COUNTS = {
        0,
        7,286,200,176,120,165,206,75,129,109,
        123,111,43,52,99,128,111,110,98,135,
        112,78,118,64,77,227,93,88,69,60,
        34,30,73,54,45,83,182,88,75,85,
        54,53,89,59,37,35,38,29,18,45,
        60,49,62,55,78,96,29,22,24,13,
        14,11,11,18,12,12,30,52,52,44,
        28,28,20,56,40,31,50,40,46,42,
        29,19,36,25,22,17,19,26,30,20,
        15,21,11,8,8,19,5,8,8,11,
        11,8,3,9,5,4,7,3,6,3,
        5,4,5,6
    };

    private static final int[][] BEGINNER_VERSES = {
        {1,1},{1,2},{1,3},{1,4},{1,5},{1,6},{1,7},
        {112,1},{112,2},{112,3},{112,4},
        {113,1},{113,2},{114,1},{114,2},
        {103,1},{103,2},{103,3},{94,5},{94,6},
        {2,255},{2,286},{65,2},{65,3},{39,53}
    };

    static String name(int surah){
        if(surah<1||surah>=NAMES.length)return "Sure "+surah;
        return NAMES[surah];
    }

    static String label(int surah,int ayah){return name(surah)+" "+surah+"/"+ayah;}

    static String[] labels(){
        String[] out=new String[114];
        for(int i=1;i<=114;i++)out[i-1]=i+" · "+name(i)+" · "+ayahCount(i)+" ayet";
        return out;
    }

    static int ayahCount(int surah){return (surah>=1&&surah<COUNTS.length)?COUNTS[surah]:1;}
    static int clampAyah(int surah,int ayah){return Math.max(1,Math.min(ayahCount(surah),ayah));}
    static int globalNumber(int surah,int ayah){
        surah=Math.max(1,Math.min(114,surah)); ayah=clampAyah(surah,ayah);
        int n=ayah; for(int i=1;i<surah;i++)n+=COUNTS[i]; return n;
    }

    static int[] suggestion(){
        int day=Calendar.getInstance().get(Calendar.DAY_OF_YEAR);
        int[] p=BEGINNER_VERSES[Math.abs(day)%BEGINNER_VERSES.length];
        return new int[]{p[0],p[1]};
    }

    private QuranMeta(){}
}
