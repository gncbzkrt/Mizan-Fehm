package com.mizan.fehm;

final class Reciters {
    static final String MAHER_64="maher64";
    static final String MAHER_128="maher128";
    static final String ALAFASY_64="alafasy64";
    static String name(String id){if(MAHER_128.equals(id))return "Mahir el-Muaykıli · 128 kbps";if(ALAFASY_64.equals(id))return "Mişârî el-Afâsî · 64 kbps";return "Mahir el-Muaykıli · 64 kbps";}
    static String dir(String id){if(MAHER_128.equals(id))return "MaherAlMuaiqly128kbps";if(ALAFASY_64.equals(id))return "Alafasy_64kbps";return "Maher_AlMuaiqly_64kbps";}
    static String url(String id,int surah,int ayah){return "https://everyayah.com/data/"+dir(id)+"/"+pad3(surah)+pad3(ayah)+".mp3";}
    static String[] ids(){return new String[]{MAHER_64,MAHER_128,ALAFASY_64};}
    static String[] names(){return new String[]{name(MAHER_64),name(MAHER_128),name(ALAFASY_64)};}
    private static String pad3(int n){if(n<10)return "00"+n;if(n<100)return "0"+n;return ""+n;}
    private Reciters(){}
}
